# دليل تحويل أَدفايز إلى APK

التطبيق الآن **PWA جاهز** — يمكن تثبيته مباشرة من المتصفح، أو تغليفه كـ APK بسهولة.

---

## 📱 الطريقة 1: التثبيت المباشر من المتصفح (الأسهل — بدون برمجة)

التطبيق الآن PWA، لذا يمكن تثبيته مباشرة على الهاتف:

### على أندرويد (Chrome):
1. افتح رابط التطبيق في Chrome
2. اضغط على قائمة (⋮) ← **"تثبيت التطبيق"** أو **"إضافة إلى الشاشة الرئيسية"**
3. سيظهر التطبيق كأيقونة على شاشتك الرئيسية
4. افتحه — سيعمل بملء الشاشة دون شريط المتصفح

### على آيفون (Safari):
1. افتح الرابط في Safari
2. اضغط زر المشاركة (⬆️) ← **"إضافة إلى الشاشة الرئيسية"**
3. اضغط **"إضافة"**

> 💡 سيظهر زر "تثبيت التطبيق" تلقائياً في أسفل الشاشة عندما يتيح المتصفح ذلك.

---

## 🤖 الطريقة 2: PWABuilder (APK حقيقي — الأسهل للمطورين)

هذه الطريقة تنتج ملف **APK حقيقي** يمكن توزيعه على Google Play.

### الخطوات:
1. انشر التطبيق على استضافة عامة (مثل Vercel، Netlify، أو أي VPS)
   ```bash
   npm run build
   # انسخ مجلد .next و public/ إلى استضافتك
   ```
2. احصل على رابط HTTPS عام للتطبيق
3. اذهب إلى **https://www.pwabuilder.com**
4. الصق رابط تطبيقك
5. اضغط **"Start"** — سيقوم PWABuilder بتحليل PWA الخاص بك
6. اختر **"Android"** من خيارات المنصات
7. اضغط **"Generate"** ثم **"Download"**
8. ستحصل على ملف **APK** + مفتاح للتوقيع

### مميزات PWABuilder:
- ✅ مجاني 100%
- ✅ لا يحتاج برمجة
- ✅ ينتج APK موقّع جاهز للتثبيت
- ✅ يدعم Google Play

---

## 🛠️ الطريقة 3: Bubblewrap (CLI من Google — للمطورين المتقدمين)

Bubblewrap هي أداة Google الرسمية لتحويل PWA إلى APK عبر TWA (Trusted Web Activity).

### المتطلبات:
- Java JDK 11+
- Android SDK (يأتي مع Android Studio)

### الخطوات:
```bash
# تثبيت الأداة
npm i -g @bubblewrap/cli

# إنشاء مشروع APK
bubblewrap init --manifest https://your-app-url.com/manifest.json

# بناء APK
bubblewrap build
```

ستجد ملف APK في:
```
your-project/app-release-signed.apk
```

---

## 📦 الطريقة 4: Capacitor (للحفاظ على كود Native)

إذا أردت لاحقاً إضافة ميزات native (كاميرا، إشعارات دفع)، استخدم Capacitor:

```bash
npm install @capacitor/core @capacitor/cli
npx cap init أَدفايز com.advaize.app --web-dir=.next

# أضف منصة Android
npx cap add android

# ابنِ المشروع
npm run build
npx cap sync

# افتح في Android Studio
npx cap open android
```

ثم من Android Studio: **Build → Build APK(s)**

---

## ✅ ما تم إنجازه في التطبيق

التطبيق الآن يحتوي على كل متطلبات PWA:

| الميزة | الحالة |
|--------|--------|
| `manifest.json` | ✅ |
| Service Worker (offline) | ✅ |
| أيقونات (192, 384, 512, maskable) | ✅ |
| apple-touch-icon | ✅ |
| favicon.ico | ✅ |
| theme-color | ✅ |
| display: standalone | ✅ |
| dir: rtl, lang: ar | ✅ |
| زر تثبيت مخصص | ✅ |

---

## 🚀 توصيتنا

**للبدء السريع:** استخدم الطريقة 1 (التثبيت المباشر) — التطبيق جاهز الآن.

**للنشر على Google Play:** استخدم الطريقة 2 (PWABuilder) — الأسهل والأفضل.

**للميزات المتقدمة:** استخدم الطريقة 4 (Capacitor) — إذا أردت إشعارات push أو وصول للكاميرا لاحقاً.
