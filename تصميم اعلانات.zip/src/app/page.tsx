import { AdGenerator } from "@/components/AdGenerator";

export default function HomePage() {
  return <AdGenerator />;
}
