/**
 * Health check endpoint.
 * يعمل في وضع الخادم ووضع الـ static export.
 * في وضع static export، يُصدَّر كـ JSON ثابت.
 */
export const dynamic = "force-static";

export async function GET() {
  return Response.json({ ok: true });
}
