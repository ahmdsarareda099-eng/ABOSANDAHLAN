/**
 * API للإعلانات المحفوظة.
 * ملاحظة: التطبيق يستخدم IndexedDB محلياً (src/lib/localStore.ts) في كلا الوضعين.
 * هذا الـ route موجود للتوافق، ويُصدَّر كـ JSON ثابت في static export.
 */
import { NextResponse } from "next/server";

export const dynamic = "force-static";

export async function GET() {
  // التطبيق يستخدم IndexedDB محلياً — لا حاجة لـ backend
  return NextResponse.json({ items: [] });
}

export async function POST(req: Request) {
  // التطبيق يحفظ محلياً في IndexedDB — لا حاجة لـ backend
  const body = await req.json();
  return NextResponse.json({ item: { ...body, id: Date.now() } });
}
