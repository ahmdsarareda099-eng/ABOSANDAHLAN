/**
 * محرك تحليل صورة المنتج.
 * يحلل البكسلات لاستخراج:
 *  - الألوان المهيمنة (k-means مبسط)
 *  - موقع المنتج داخل الإطار (saliency)
 *  - متوسط السطوع والتباين
 * هذه البيانات تُغذّي قرارات التصميم التلقائية (اختيار الخلفية، الألوان، الموضع).
 */

import type { RGB } from "./color";
import { rgbToHsl, luminance } from "./color";

export interface ImageAnalysis {
  /** الألوان المهيمنة مرتبة من الأكثر تكراراً */
  dominantColors: RGB[];
  /** لون المنتج الأساسي (أكثر لون مميّز للشيء) */
  primaryColor: RGB;
  /** لون خلفية الصورة الأصلية */
  backgroundColor: RGB;
  /** السطوع المتوسط 0..1 */
  brightness: number;
  /** التباين المتوسط 0..1 */
  contrast: number;
  /** مركز الثقل البصري للمنتج (نسبة من الصورة) */
  centroid: { x: number; y: number };
  /** مدى "نظافة" الخلفية الأصلية (قرب الأطراف من لون واحد) */
  backgroundCleanliness: number;
  /** عرض وارتفاع الصورة الأصلية */
  width: number;
  height: number;
}

/**
 * استخراج عيّنة من البكسلات من canvas (تخفيف العيّنة للأداء).
 */
function samplePixels(imageData: ImageData, step = 4): RGB[] {
  const { data, width, height } = imageData;
  const pixels: RGB[] = [];
  for (let y = 0; y < height; y += step) {
    for (let x = 0; x < width; x += step) {
      const i = (y * width + x) * 4;
      const a = data[i + 3];
      if (a < 125) continue; // تجاهل الشفاف
      pixels.push({ r: data[i], g: data[i + 1], b: data[i + 2] });
    }
  }
  return pixels;
}

/**
 * تجميع الألوان المهيمنة باستخدام خوارزمية k-means مبسطة.
 */
function kMeans(pixels: RGB[], k = 5, iterations = 8): RGB[] {
  if (pixels.length === 0) return [];
  // بذور عشوائية ثابتة (لإعادة إنتاجية)
  const seedIndexes = [0, Math.floor(pixels.length / k), Math.floor(pixels.length / 2), Math.floor((pixels.length * 3) / 4), pixels.length - 1];
  const centroids: RGB[] = seedIndexes.slice(0, k).map((i) => ({ ...pixels[i] }));

  for (let iter = 0; iter < iterations; iter++) {
    const clusters: RGB[][] = Array.from({ length: k }, () => []);
    for (const px of pixels) {
      let best = 0;
      let bestDist = Infinity;
      for (let c = 0; c < k; c++) {
        const dr = px.r - centroids[c].r;
        const dg = px.g - centroids[c].g;
        const db = px.b - centroids[c].b;
        const dist = dr * dr + dg * dg + db * db;
        if (dist < bestDist) {
          bestDist = dist;
          best = c;
        }
      }
      clusters[best].push(px);
    }
    for (let c = 0; c < k; c++) {
      if (clusters[c].length === 0) continue;
      const sum = clusters[c].reduce(
        (acc, p) => ({ r: acc.r + p.r, g: acc.g + p.g, b: acc.b + p.b }),
        { r: 0, g: 0, b: 0 }
      );
      centroids[c] = {
        r: Math.round(sum.r / clusters[c].length),
        g: Math.round(sum.g / clusters[c].length),
        b: Math.round(sum.b / clusters[c].length),
      };
    }
  }
  // ترتيب حسب الحجم (عدد البكسلات في كل مجموعة يُعاد حسابه)
  const counts = centroids.map((c) => {
    let count = 0;
    for (const px of pixels) {
      const dr = px.r - c.r;
      const dg = px.g - c.g;
      const db = px.b - c.b;
      if (dr * dr + dg * dg + db * db < 4000) count++;
    }
    return count;
  });
  const combined = centroids
    .map((c, i) => ({ c, count: counts[i] }))
    .sort((a, b) => b.count - a.count);
  return combined.map((x) => x.c);
}

/**
 * اختيار "اللون المميّز" للمنتج: أكثر لون مشبّع وبعيد عن لون الخلفية.
 */
function pickPrimaryColor(dominant: RGB[], background: RGB): RGB {
  let best = dominant[0];
  let bestScore = -Infinity;
  for (const c of dominant) {
    const hsl = rgbToHsl(c);
    // نفضل الألوان المشبعة والبعيدة عن لون الخلفية
    const distFromBg =
      Math.pow(c.r - background.r, 2) +
      Math.pow(c.g - background.g, 2) +
      Math.pow(c.b - background.b, 2);
    const score = hsl.s * 1.5 + Math.sqrt(distFromBg) * 0.4 - Math.abs(hsl.l - 50) * 0.2;
    if (score > bestScore) {
      bestScore = score;
      best = c;
    }
  }
  return best;
}

/**
 * تحديد لون الخلفية الأصلية (الأكثر تكراراً قرب الحواف).
 */
function detectBackgroundColor(imageData: ImageData): RGB {
  const { data, width, height } = imageData;
  const edgePixels: RGB[] = [];
  const margin = Math.max(2, Math.floor(Math.min(width, height) * 0.03));
  const collect = (x: number, y: number) => {
    const i = (y * width + x) * 4;
    if (data[i + 3] < 125) return;
    edgePixels.push({ r: data[i], g: data[i + 1], b: data[i + 2] });
  };
  for (let x = 0; x < width; x += 2) {
    collect(x, margin);
    collect(x, height - 1 - margin);
  }
  for (let y = 0; y < height; y += 2) {
    collect(margin, y);
    collect(width - 1 - margin, y);
  }
  if (edgePixels.length === 0) return { r: 240, g: 240, b: 240 };
  const sum = edgePixels.reduce(
    (acc, p) => ({ r: acc.r + p.r, g: acc.g + p.g, b: acc.b + p.b }),
    { r: 0, g: 0, b: 0 }
  );
  return {
    r: Math.round(sum.r / edgePixels.length),
    g: Math.round(sum.g / edgePixels.length),
    b: Math.round(sum.b / edgePixels.length),
  };
}

/**
 * حساب مركز الثقل البصري (أين يتركز "الشيء" في الصورة).
 * نستخدم تباين البكسل عن لون الخلفية كمقياس للأهمية.
 */
function computeCentroid(imageData: ImageData, background: RGB): { x: number; y: number } {
  const { data, width, height } = imageData;
  let totalWeight = 0;
  let sumX = 0;
  let sumY = 0;
  const step = 3;
  for (let y = 0; y < height; y += step) {
    for (let x = 0; x < width; x += step) {
      const i = (y * width + x) * 4;
      if (data[i + 3] < 125) continue;
      const dr = data[i] - background.r;
      const dg = data[i + 1] - background.g;
      const db = data[i + 2] - background.b;
      const dist = Math.sqrt(dr * dr + dg * dg + db * db);
      if (dist < 20) continue; // جزء من الخلفية
      const w = dist;
      totalWeight += w;
      sumX += x * w;
      sumY += y * w;
    }
  }
  if (totalWeight === 0) return { x: 0.5, y: 0.5 };
  return { x: sumX / totalWeight / width, y: sumY / totalWeight / height };
}

/**
 * الدالة الرئيسية لتحليل صورة منتج.
 */
export function analyzeImage(imageData: ImageData): ImageAnalysis {
  const pixels = samplePixels(imageData, 5);
  const dominant = kMeans(pixels, 5, 8);
  const background = detectBackgroundColor(imageData);
  const primary = pickPrimaryColor(dominant, background);
  const centroid = computeCentroid(imageData, background);

  // السطوع والتباين
  let sumLum = 0;
  let sumSqDiff = 0;
  let count = 0;
  const step = 6;
  const { data, width, height } = imageData;
  for (let y = 0; y < height; y += step) {
    for (let x = 0; x < width; x += step) {
      const i = (y * width + x) * 4;
      if (data[i + 3] < 125) continue;
      const px = { r: data[i], g: data[i + 1], b: data[i + 2] };
      const lum = luminance(px);
      sumLum += lum;
      count++;
    }
  }
  const avgLum = count > 0 ? sumLum / count : 0.5;
  for (let y = 0; y < height; y += step) {
    for (let x = 0; x < width; x += step) {
      const i = (y * width + x) * 4;
      if (data[i + 3] < 125) continue;
      const px = { r: data[i], g: data[i + 1], b: data[i + 2] };
      const lum = luminance(px);
      sumSqDiff += (lum - avgLum) ** 2;
    }
  }
  const contrast = count > 0 ? Math.sqrt(sumSqDiff / count) : 0.2;

  // نظافة الخلفية: مدى تجانس الأطراف
  let edgeVariance = 0;
  const edgeLums: number[] = [];
  const margin = Math.max(2, Math.floor(Math.min(width, height) * 0.03));
  const collectLum = (x: number, y: number) => {
    const i = (y * width + x) * 4;
    if (data[i + 3] < 125) return;
    edgeLums.push(luminance({ r: data[i], g: data[i + 1], b: data[i + 2] }));
  };
  for (let x = 0; x < width; x += 3) {
    collectLum(x, margin);
    collectLum(x, height - 1 - margin);
  }
  for (let y = 0; y < height; y += 3) {
    collectLum(margin, y);
    collectLum(width - 1 - margin, y);
  }
  if (edgeLums.length > 0) {
    const meanEdge = edgeLums.reduce((a, b) => a + b, 0) / edgeLums.length;
    edgeVariance =
      edgeLums.reduce((a, b) => a + (b - meanEdge) ** 2, 0) / edgeLums.length;
  }
  const backgroundCleanliness = Math.max(0, 1 - edgeVariance * 6);

  return {
    dominantColors: dominant,
    primaryColor: primary,
    backgroundColor: background,
    brightness: avgLum,
    contrast: Math.min(1, contrast * 3),
    centroid,
    backgroundCleanliness,
    width: imageData.width,
    height: imageData.height,
  };
}
