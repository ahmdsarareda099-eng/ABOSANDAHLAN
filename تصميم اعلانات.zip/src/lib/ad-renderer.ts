/**
 * محرك رسم الإعلان على Canvas.
 * يأخذ صورة المنتج + التحليل + الإعدادات ويرسم إعلاناً احترافياً.
 * يعمل بالكامل في المتصفح (client-side) دون الحاجة لأي API خارجي.
 */

import type { ImageAnalysis } from "./image-analysis";
import type { Palette } from "./palettes";
import { rgbToHex, lighten, darken, mixColors } from "./color";
import type { RGB } from "./color";
import type { TemplateId } from "./templates";

export type AspectRatio = "square" | "story" | "landscape";
export type ProductPosition = "center" | "left" | "right";
export type BackgroundStyle = "gradient" | "blur" | "solid" | "pattern" | "split";

export interface AdConfig {
  template: TemplateId;
  palette: Palette;
  headline: string;
  subtext: string;
  cta: string;
  brand: string;
  aspect: AspectRatio;
  productPosition: ProductPosition;
  backgroundStyle: BackgroundStyle;
  showPrice: boolean;
  price: string;
}

export const ASPECT_DIMENSIONS: Record<AspectRatio, { w: number; h: number }> = {
  square: { w: 1080, h: 1080 },
  story: { w: 1080, h: 1920 },
  landscape: { w: 1920, h: 1080 },
};

/**
 * رسم تدرج لوني قطري/خطي على الخلفية.
 */
function drawGradientBackground(
  ctx: CanvasRenderingContext2D,
  w: number,
  h: number,
  palette: Palette
) {
  const grad = ctx.createLinearGradient(0, 0, w, h);
  grad.addColorStop(0, rgbToHex(palette.bg));
  grad.addColorStop(0.5, rgbToHex(mixColors(palette.bg, palette.bg2, 0.5)));
  grad.addColorStop(1, rgbToHex(palette.bg2));
  ctx.fillStyle = grad;
  ctx.fillRect(0, 0, w, h);
}

/**
 * خلفية مع توهجات ضبابية (aurora) لإضافة عمق.
 */
function drawAuroraBlobs(
  ctx: CanvasRenderingContext2D,
  w: number,
  h: number,
  palette: Palette
) {
  const blobs = [
    { x: w * 0.2, y: h * 0.15, r: w * 0.45, color: palette.accent },
    { x: w * 0.85, y: h * 0.75, r: w * 0.5, color: palette.accent2 },
    { x: w * 0.5, y: h * 0.5, r: w * 0.35, color: mixColors(palette.accent, palette.bg, 0.3) },
  ];
  for (const blob of blobs) {
    const g = ctx.createRadialGradient(blob.x, blob.y, 0, blob.x, blob.y, blob.r);
    g.addColorStop(0, `${rgbToHex(blob.color)}55`);
    g.addColorStop(1, `${rgbToHex(blob.color)}00`);
    ctx.fillStyle = g;
    ctx.fillRect(0, 0, w, h);
  }
}

/**
 * رسم نقاط ضوئية متلألئة (bokeh).
 */
function drawBokeh(
  ctx: CanvasRenderingContext2D,
  w: number,
  h: number,
  palette: Palette,
  count: number,
  seed: number
) {
  ctx.save();
  for (let i = 0; i < count; i++) {
    const r = ((seed * (i + 1) * 9301 + 49297) % 233280) / 233280;
    const r2 = ((seed * (i + 1) * 49297 + 9301) % 233280) / 233280;
    const x = r * w;
    const y = r2 * h;
    const radius = 10 + r * 50;
    const alpha = 0.05 + r2 * 0.15;
    const g = ctx.createRadialGradient(x, y, 0, x, y, radius);
    g.addColorStop(0, `${rgbToHex(palette.accent2)}${Math.floor(alpha * 255).toString(16).padStart(2, "0")}`);
    g.addColorStop(1, `${rgbToHex(palette.accent2)}00`);
    ctx.fillStyle = g;
    ctx.beginPath();
    ctx.arc(x, y, radius, 0, Math.PI * 2);
    ctx.fill();
  }
  ctx.restore();
}

/**
 * رسم نمط هندسي متكرر.
 */
function drawGeometricPattern(
  ctx: CanvasRenderingContext2D,
  w: number,
  h: number,
  palette: Palette,
  template: TemplateId
) {
  ctx.save();
  ctx.globalAlpha = 0.06;
  ctx.strokeStyle = rgbToHex(palette.accent);
  ctx.lineWidth = 1.5;

  if (template === "neon" || template === "vibrant") {
    // خطوط متقاطعة
    const step = 80;
    for (let x = -h; x < w + h; x += step) {
      ctx.beginPath();
      ctx.moveTo(x, 0);
      ctx.lineTo(x + h, h);
      ctx.stroke();
    }
  } else if (template === "corporate" || template === "editorial") {
    // نقاط
    ctx.fillStyle = rgbToHex(palette.accent);
    const step = 60;
    for (let x = step; x < w; x += step) {
      for (let y = step; y < h; y += step) {
        ctx.beginPath();
        ctx.arc(x, y, 2, 0, Math.PI * 2);
        ctx.fill();
      }
    }
  } else {
    // دوائر متحدة المركز
    ctx.globalAlpha = 0.04;
    for (let i = 0; i < 8; i++) {
      ctx.beginPath();
      ctx.arc(w * 0.5, h * 0.5, 100 + i * 80, 0, Math.PI * 2);
      ctx.stroke();
    }
  }
  ctx.restore();
}

/**
 * رسم صورة المنتج مع ظل وتوهج.
 */
function drawProduct(
  ctx: CanvasRenderingContext2D,
  productImg: HTMLImageElement | HTMLCanvasElement,
  w: number,
  h: number,
  palette: Palette,
  position: ProductPosition,
  template: TemplateId,
  analysis: ImageAnalysis,
  aspect: AspectRatio
) {
  // حساب أبعاد المنتج للحفاظ على النسبة
  const maxW = w * 0.62;
  const maxH = h * (aspect === "story" ? 0.45 : 0.55);
  const ratio = (productImg as HTMLImageElement).naturalWidth
    ? (productImg as HTMLImageElement).naturalWidth / (productImg as HTMLImageElement).naturalHeight
    : (productImg.width / productImg.height);
  let pw = maxW;
  let ph = pw / ratio;
  if (ph > maxH) {
    ph = maxH;
    pw = ph * ratio;
  }

  let px: number;
  let py: number;
  if (position === "left") {
    px = w * 0.08;
  } else if (position === "right") {
    px = w - pw - w * 0.08;
  } else {
    px = (w - pw) / 2;
  }
  // الموضع الرأسي يعتمد على القالب
  if (template === "editorial" || template === "corporate") {
    py = h * 0.18;
  } else if (aspect === "story") {
    py = h * 0.25;
  } else {
    py = (h - ph) / 2;
  }

  ctx.save();

  // ظل ناعم تحت المنتج
  if (template !== "minimal") {
    const shadowGrad = ctx.createRadialGradient(
      px + pw / 2,
      py + ph + 20,
      0,
      px + pw / 2,
      py + ph + 20,
      pw * 0.6
    );
    shadowGrad.addColorStop(0, "rgba(0,0,0,0.55)");
    shadowGrad.addColorStop(1, "rgba(0,0,0,0)");
    ctx.fillStyle = shadowGrad;
    ctx.beginPath();
    ctx.ellipse(px + pw / 2, py + ph + 20, pw * 0.5, 25, 0, 0, Math.PI * 2);
    ctx.fill();
  }

  // توهج خلف المنتج
  if (template === "neon" || template === "vibrant" || template === "luxury") {
    const glowGrad = ctx.createRadialGradient(
      px + pw / 2,
      py + ph / 2,
      0,
      px + pw / 2,
      py + ph / 2,
      pw * 0.8
    );
    const glowColor = template === "neon" ? palette.accent2 : palette.accent;
    glowGrad.addColorStop(0, `${rgbToHex(glowColor)}44`);
    glowGrad.addColorStop(1, `${rgbToHex(glowColor)}00`);
    ctx.fillStyle = glowGrad;
    ctx.fillRect(px - pw * 0.3, py - ph * 0.3, pw * 1.6, ph * 1.6);
  }

  // إطار ذهبي للقالب الفاخر
  if (template === "luxury") {
    ctx.strokeStyle = rgbToHex(palette.accent);
    ctx.lineWidth = 2;
    const pad = 14;
    ctx.strokeRect(px - pad, py - pad, pw + pad * 2, ph + pad * 2);
    // زخارف في الأركان
    const corner = 28;
    ctx.lineWidth = 3;
    [
      [px - pad, py - pad, 1, 1],
      [px + pw + pad, py - pad, -1, 1],
      [px - pad, py + ph + pad, 1, -1],
      [px + pw + pad, py + ph + pad, -1, -1],
    ].forEach(([cx, cy, dx, dy]) => {
      ctx.beginPath();
      ctx.moveTo(cx, cy + corner * dy);
      ctx.lineTo(cx, cy);
      ctx.lineTo(cx + corner * dx, cy);
      ctx.stroke();
    });
  }

  // رسم المنتج
  ctx.drawImage(productImg, px, py, pw, ph);

  ctx.restore();
}

/**
 * رسم النص الرئيسي للإعلان.
 */
function drawText(
  ctx: CanvasRenderingContext2D,
  w: number,
  h: number,
  config: AdConfig,
  palette: Palette
) {
  ctx.save();
  ctx.textAlign = "center";
  ctx.direction = "rtl";

  const isLight = palette.bg.r + palette.bg.g + palette.bg.b > 380;
  const headlineColor = rgbToHex(palette.text);
  const mutedColor = rgbToHex(palette.textMuted);
  const accentColor = rgbToHex(palette.accent);

  // العلامة التجارية في الأعلى
  if (config.brand) {
    ctx.font = `600 ${Math.round(h * 0.022)}px Cairo, sans-serif`;
    ctx.fillStyle = accentColor;
    ctx.letterSpacing = "4px";
    ctx.fillText(config.brand.toUpperCase(), w / 2, h * 0.085);
    // خط تحت العلامة
    ctx.strokeStyle = accentColor;
    ctx.lineWidth = 1.5;
    ctx.beginPath();
    ctx.moveTo(w / 2 - 30, h * 0.105);
    ctx.lineTo(w / 2 + 30, h * 0.105);
    ctx.stroke();
  }

  // العنوان الرئيسي
  if (config.headline) {
    const headlineSize = config.template === "editorial" ? h * 0.075 : h * 0.058;
    ctx.font = `800 ${Math.round(headlineSize)}px Cairo, sans-serif`;
    ctx.fillStyle = headlineColor;

    // تقسيم النص إذا كان طويلاً
    const maxWidth = w * 0.85;
    const words = config.headline.split(" ");
    const lines: string[] = [];
    let currentLine = "";
    for (const word of words) {
      const testLine = currentLine ? currentLine + " " + word : word;
      const metrics = ctx.measureText(testLine);
      if (metrics.width > maxWidth && currentLine) {
        lines.push(currentLine);
        currentLine = word;
      } else {
        currentLine = testLine;
      }
    }
    if (currentLine) lines.push(currentLine);

    const lineHeight = headlineSize * 1.15;
    const startY = config.template === "editorial" ? h * 0.88 : h * 0.86;
    for (let i = lines.length - 1; i >= 0; i--) {
      const y = startY - (lines.length - 1 - i) * lineHeight;
      ctx.fillText(lines[i], w / 2, y);
    }

    // خط زخرفي تحت العنوان
    if (config.template === "luxury" || config.template === "editorial") {
      ctx.strokeStyle = accentColor;
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.moveTo(w / 2 - 40, startY + 18);
      ctx.lineTo(w / 2 + 40, startY + 18);
      ctx.stroke();
    }
  }

  // النص الفرعي
  if (config.subtext) {
    const subSize = Math.round(h * 0.024);
    ctx.font = `400 ${subSize}px Cairo, sans-serif`;
    ctx.fillStyle = mutedColor;
    const maxWidth = w * 0.7;
    const words = config.subtext.split(" ");
    const lines: string[] = [];
    let currentLine = "";
    for (const word of words) {
      const testLine = currentLine ? currentLine + " " + word : word;
      const metrics = ctx.measureText(testLine);
      if (metrics.width > maxWidth && currentLine) {
        lines.push(currentLine);
        currentLine = word;
      } else {
        currentLine = testLine;
      }
    }
    if (currentLine) lines.push(currentLine);

    const headlineHeight = config.headline ? h * 0.058 * 1.15 * Math.min(lines.length, 2) : 0;
    const startY = h * 0.86 - headlineHeight - h * 0.04;
    for (let i = lines.length - 1; i >= 0; i--) {
      const y = startY - (lines.length - 1 - i) * (subSize * 1.3);
      ctx.fillText(lines[i], w / 2, y);
    }
  }

  // زر CTA
  if (config.cta) {
    const ctaSize = Math.round(h * 0.026);
    ctx.font = `700 ${ctaSize}px Cairo, sans-serif`;
    const metrics = ctx.measureText(config.cta);
    const padX = 32;
    const padY = 16;
    const btnW = metrics.width + padX * 2;
    const btnH = ctaSize + padY * 2;
    const btnX = (w - btnW) / 2;
    const btnY = h * 0.93 - btnH;

    // خلفية الزر
    const btnGrad = ctx.createLinearGradient(btnX, btnY, btnX + btnW, btnY);
    btnGrad.addColorStop(0, rgbToHex(palette.accent));
    btnGrad.addColorStop(1, rgbToHex(palette.accent2));
    ctx.fillStyle = btnGrad;

    // زوايا مدورة
    const radius = btnH / 2;
    ctx.beginPath();
    ctx.moveTo(btnX + radius, btnY);
    ctx.arcTo(btnX + btnW, btnY, btnX + btnW, btnY + btnH, radius);
    ctx.arcTo(btnX + btnW, btnY + btnH, btnX, btnY + btnH, radius);
    ctx.arcTo(btnX, btnY + btnH, btnX, btnY, radius);
    ctx.arcTo(btnX, btnY, btnX + btnW, btnY, radius);
    ctx.closePath();
    ctx.fill();

    // نص الزر
    ctx.fillStyle = rgbToHex(palette.onAccent);
    ctx.textAlign = "center";
    ctx.textBaseline = "middle";
    ctx.fillText(config.cta, btnX + btnW / 2, btnY + btnH / 2 + 2);
    ctx.textBaseline = "alphabetic";
  }

  // شارة السعر
  if (config.showPrice && config.price) {
    const priceSize = Math.round(h * 0.032);
    ctx.font = `800 ${priceSize}px Cairo, sans-serif`;
    const priceText = config.price;
    const metrics = ctx.measureText(priceText);
    const padX = 24;
    const padY = 12;
    const badgeW = metrics.width + padX * 2;
    const badgeH = priceSize + padY * 2;
    const badgeX = w * 0.08;
    const badgeY = h * 0.12;

    // خلفية الشارة
    ctx.fillStyle = rgbToHex(palette.accent);
    const r = 12;
    ctx.beginPath();
    ctx.moveTo(badgeX + r, badgeY);
    ctx.arcTo(badgeX + badgeW, badgeY, badgeX + badgeW, badgeY + badgeH, r);
    ctx.arcTo(badgeX + badgeW, badgeY + badgeH, badgeX, badgeY + badgeH, r);
    ctx.arcTo(badgeX, badgeY + badgeH, badgeX, badgeY, r);
    ctx.arcTo(badgeX, badgeY, badgeX + badgeW, badgeY, r);
    ctx.closePath();
    ctx.fill();

    ctx.fillStyle = rgbToHex(palette.onAccent);
    ctx.textAlign = "center";
    ctx.textBaseline = "middle";
    ctx.fillText(priceText, badgeX + badgeW / 2, badgeY + badgeH / 2 + 2);
    ctx.textBaseline = "alphabetic";
  }

  ctx.restore();
}

/**
 * رسم طبقة ضبابية من صورة المنتج كخلفية.
 */
function drawBlurBackground(
  ctx: CanvasRenderingContext2D,
  productImg: HTMLImageElement | HTMLCanvasElement,
  w: number,
  h: number
) {
  ctx.save();
  ctx.filter = "blur(40px) brightness(0.4) saturate(1.4)";
  // رسم الصورة لتغطي الإطار كاملاً (cover)
  const ir = (productImg as HTMLImageElement).naturalWidth
    ? (productImg as HTMLImageElement).naturalWidth / (productImg as HTMLImageElement).naturalHeight
    : productImg.width / productImg.height;
  const cr = w / h;
  let dw = w,
    dh = h,
    dx = 0,
    dy = 0;
  if (ir > cr) {
    dh = h;
    dw = h * ir;
    dx = (w - dw) / 2;
  } else {
    dw = w;
    dh = w / ir;
    dy = (h - dh) / 2;
  }
  ctx.drawImage(productImg, dx, dy, dw, dh);
  ctx.filter = "none";
  // طبقة معتمة فوق الضباب
  ctx.fillStyle = "rgba(0,0,0,0.45)";
  ctx.fillRect(0, 0, w, h);
  ctx.restore();
}

/**
 * رسم خلفية منقسمة (نصفين بلونين).
 */
function drawSplitBackground(
  ctx: CanvasRenderingContext2D,
  w: number,
  h: number,
  palette: Palette
) {
  const grad = ctx.createLinearGradient(0, 0, 0, h);
  grad.addColorStop(0, rgbToHex(palette.bg));
  grad.addColorStop(0.5, rgbToHex(palette.bg));
  grad.addColorStop(0.5, rgbToHex(palette.bg2));
  grad.addColorStop(1, rgbToHex(palette.bg2));
  ctx.fillStyle = grad;
  ctx.fillRect(0, 0, w, h);
}

/**
 * vignette (تعتيم الحواف).
 */
function drawVignette(ctx: CanvasRenderingContext2D, w: number, h: number, strength = 0.4) {
  const grad = ctx.createRadialGradient(w / 2, h / 2, Math.min(w, h) * 0.3, w / 2, h / 2, Math.max(w, h) * 0.75);
  grad.addColorStop(0, "rgba(0,0,0,0)");
  grad.addColorStop(1, `rgba(0,0,0,${strength})`);
  ctx.fillStyle = grad;
  ctx.fillRect(0, 0, w, h);
}

/**
 * الدالة الرئيسية لرسم الإعلان كاملاً.
 */
export function renderAd(
  ctx: CanvasRenderingContext2D,
  productImg: HTMLImageElement | HTMLCanvasElement,
  analysis: ImageAnalysis | null,
  config: AdConfig
) {
  const { w, h } = ASPECT_DIMENSIONS[config.aspect];
  ctx.canvas.width = w;
  ctx.canvas.height = h;
  ctx.clearRect(0, 0, w, h);

  const palette = config.palette;

  // 1. الخلفية
  switch (config.backgroundStyle) {
    case "blur":
      drawBlurBackground(ctx, productImg, w, h);
      drawGradientBackground(ctx, w, h, palette);
      ctx.globalAlpha = 0.4;
      drawGradientBackground(ctx, w, h, palette);
      ctx.globalAlpha = 1;
      break;
    case "solid":
      ctx.fillStyle = rgbToHex(palette.bg);
      ctx.fillRect(0, 0, w, h);
      break;
    case "split":
      drawSplitBackground(ctx, w, h, palette);
      break;
    case "pattern":
      drawGradientBackground(ctx, w, h, palette);
      drawGeometricPattern(ctx, w, h, palette, config.template);
      break;
    case "gradient":
    default:
      drawGradientBackground(ctx, w, h, palette);
      break;
  }

  // 2. إضافات حسب القالب
  if (config.template === "luxury" || config.template === "neon" || config.template === "vibrant") {
    drawAuroraBlobs(ctx, w, h, palette);
  }
  if (config.template === "neon" || config.template === "vibrant" || config.template === "luxury") {
    drawBokeh(ctx, w, h, palette, config.template === "neon" ? 18 : 10, 42);
  }

  // 3. المنتج
  drawProduct(ctx, productImg, w, h, palette, config.productPosition, config.template, analysis!, config.aspect);

  // 4. النص والعناصر
  drawText(ctx, w, h, config, palette);

  // 5. اللمسات النهائية
  if (config.template === "luxury" || config.template === "editorial" || config.template === "minimal") {
    drawVignette(ctx, w, h, config.template === "minimal" ? 0.25 : 0.35);
  }
}

/**
 * تصدير الـ canvas كـ dataURL بصيغة PNG.
 */
export function canvasToDataURL(canvas: HTMLCanvasElement, quality = 0.92): string {
  return canvas.toDataURL("image/png");
}

/**
 * تصدير الـ canvas كـ Blob للتحميل.
 */
export function canvasToBlob(canvas: HTMLCanvasElement): Promise<Blob> {
  return new Promise((resolve) => {
    canvas.toBlob((blob) => {
      if (blob) resolve(blob);
      else resolve(new Blob());
    }, "image/png");
  });
}
