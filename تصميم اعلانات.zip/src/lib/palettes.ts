/**
 * لوحات ألوان جاهزة للإعلانات.
 * كل لوحة تحدّد الخلفية والألوان المميزة والنص.
 */

import type { RGB } from "./color";
import { hexToRgb, rgbToHex, lighten, darken, complementary } from "./color";

export interface Palette {
  id: string;
  name: string;
  nameEn: string;
  /** لون الخلفية الأساسي */
  bg: RGB;
  /** لون الخلفية الثانوي للتدرج */
  bg2: RGB;
  /** لون مميز رئيسي */
  accent: RGB;
  /** لون مميز ثانوي */
  accent2: RGB;
  /** لون النص الأساسي */
  text: RGB;
  /** لون النص الفرعي */
  textMuted: RGB;
  /** لون النص على الأزرار */
  onAccent: RGB;
}

export const PALETTES: Palette[] = [
  {
    id: "midnight-gold",
    name: "ذهبي منتصف الليل",
    nameEn: "Midnight Gold",
    bg: hexToRgb("#0d0d12"),
    bg2: hexToRgb("#1a1622"),
    accent: hexToRgb("#d4a574"),
    accent2: hexToRgb("#f5d9a8"),
    text: hexToRgb("#f5f0e6"),
    textMuted: hexToRgb("#a89880"),
    onAccent: hexToRgb("#0d0d12"),
  },
  {
    id: "royal-violet",
    name: "البنفسجي الملكي",
    nameEn: "Royal Violet",
    bg: hexToRgb("#1a0b2e"),
    bg2: hexToRgb("#3d1a5e"),
    accent: hexToRgb("#a855f7"),
    accent2: hexToRgb("#c084fc"),
    text: hexToRgb("#f3e8ff"),
    textMuted: hexToRgb("#c4b5fd"),
    onAccent: hexToRgb("#ffffff"),
  },
  {
    id: "rose-noir",
    name: "الوردة السوداء",
    nameEn: "Rose Noir",
    bg: hexToRgb("#1a0a14"),
    bg2: hexToRgb("#3d1525"),
    accent: hexToRgb("#ff5c8a"),
    accent2: hexToRgb("#ff9eb5"),
    text: hexToRgb("#ffe4ec"),
    textMuted: hexToRgb("#d4a0b0"),
    onAccent: hexToRgb("#1a0a14"),
  },
  {
    id: "emerald-luxe",
    name: "الزمردي الفاخر",
    nameEn: "Emerald Luxe",
    bg: hexToRgb("#061410"),
    bg2: hexToRgb("#0f2a20"),
    accent: hexToRgb("#10b981"),
    accent2: hexToRgb("#6ee7b7"),
    text: hexToRgb("#e6fff5"),
    textMuted: hexToRgb("#9dd5b8"),
    onAccent: hexToRgb("#061410"),
  },
  {
    id: "ocean-deep",
    name: "المحيط العميق",
    nameEn: "Ocean Deep",
    bg: hexToRgb("#051428"),
    bg2: hexToRgb("#0f3460"),
    accent: hexToRgb("#00d4ff"),
    accent2: hexToRgb("#7dd3fc"),
    text: hexToRgb("#e0f7ff"),
    textMuted: hexToRgb("#8fb8d4"),
    onAccent: hexToRgb("#051428"),
  },
  {
    id: "sunset-bloom",
    name: "غروب متوهج",
    nameEn: "Sunset Bloom",
    bg: hexToRgb("#2a0a14"),
    bg2: hexToRgb("#5e1a2e"),
    accent: hexToRgb("#ff6b35"),
    accent2: hexToRgb("#ffb347"),
    text: hexToRgb("#fff0e6"),
    textMuted: hexToRgb("#e0a890"),
    onAccent: hexToRgb("#2a0a14"),
  },
  {
    id: "mono-clean",
    name: "أبيض نقي",
    nameEn: "Pure White",
    bg: hexToRgb("#f5f5f0"),
    bg2: hexToRgb("#ffffff"),
    accent: hexToRgb("#1a1a1a"),
    accent2: hexToRgb("#525252"),
    text: hexToRgb("#0a0a0a"),
    textMuted: hexToRgb("#525252"),
    onAccent: hexToRgb("#ffffff"),
  },
  {
    id: "cream-warm",
    name: "كريمي دافئ",
    nameEn: "Warm Cream",
    bg: hexToRgb("#1c1408"),
    bg2: hexToRgb("#3d2810"),
    accent: hexToRgb("#e8b860"),
    accent2: hexToRgb("#f5d9a8"),
    text: hexToRgb("#fdf6e3"),
    textMuted: hexToRgb("#c4a878"),
    onAccent: hexToRgb("#1c1408"),
  },
];

/**
 * توليد لوحة ألوان "ذكية" من تحليل المنتج.
 * تأخذ اللون المهيمن للمنتج وتبني حوله لوحة متناغمة.
 */
export function generateSmartPalette(
  primaryColor: RGB,
  brightness: number
): Palette {
  // خلفية داكنة أنيقة مع تدرج من لون المنتج المخفّف
  const bgBase = brightness > 0.5 ? darken(primaryColor, 60) : darken(primaryColor, 50);
  const bg2 = darken(primaryColor, 30);
  const accent = primaryColor;
  const accent2 = lighten(primaryColor, 25);
  const text = lighten(primaryColor, 70);
  const textMuted = lighten(primaryColor, 35);
  const onAccent = brightness > 0.55 ? { r: 10, g: 10, b: 15 } : { r: 250, g: 248, b: 240 };

  return {
    id: "smart-auto",
    name: "ذكي تلقائي",
    nameEn: "Smart Auto",
    bg: bgBase,
    bg2,
    accent,
    accent2,
    text,
    textMuted,
    onAccent,
  };
}

export function getPalette(id: string): Palette {
  return PALETTES.find((p) => p.id === id) ?? PALETTES[0];
}

export { rgbToHex, complementary };
