/**
 * أدوات معالجة الألوان وتحليل الصور.
 * تُستخدم لاستخراج الهوية اللونية للمنتج تلقائياً قبل توليد الإعلان.
 */

export type RGB = { r: number; g: number; b: number };
export type HSL = { h: number; s: number; l: number };

/** تحويل RGB إلى HSL */
export function rgbToHsl({ r, g, b }: RGB): HSL {
  r /= 255;
  g /= 255;
  b /= 255;
  const max = Math.max(r, g, b);
  const min = Math.min(r, g, b);
  const l = (max + min) / 2;
  let h = 0;
  let s = 0;
  if (max !== min) {
    const d = max - min;
    s = l > 0.5 ? d / (2 - max - min) : d / (max + min);
    switch (max) {
      case r:
        h = (g - b) / d + (g < b ? 6 : 0);
        break;
      case g:
        h = (b - r) / d + 2;
        break;
      case b:
        h = (r - g) / d + 4;
        break;
    }
    h /= 6;
  }
  return { h: h * 360, s: s * 100, l: l * 100 };
}

/** تحويل HSL إلى RGB */
export function hslToRgb({ h, s, l }: HSL): RGB {
  h /= 360;
  s /= 100;
  l /= 100;
  let r: number, g: number, b: number;
  if (s === 0) {
    r = g = b = l;
  } else {
    const hue2rgb = (p: number, q: number, t: number) => {
      if (t < 0) t += 1;
      if (t > 1) t -= 1;
      if (t < 1 / 6) return p + (q - p) * 6 * t;
      if (t < 1 / 2) return q;
      if (t < 2 / 3) return p + (q - p) * (2 / 3 - t) * 6;
      return p;
    };
    const q = l < 0.5 ? l * (1 + s) : l + s - l * s;
    const p = 2 * l - q;
    r = hue2rgb(p, q, h + 1 / 3);
    g = hue2rgb(p, q, h);
    b = hue2rgb(p, q, h - 1 / 3);
  }
  return { r: Math.round(r * 255), g: Math.round(g * 255), b: Math.round(b * 255) };
}

/** تحويل RGB إلى HEX */
export function rgbToHex({ r, g, b }: RGB): string {
  return (
    "#" +
    [r, g, b]
      .map((x) => Math.max(0, Math.min(255, Math.round(x))).toString(16).padStart(2, "0"))
      .join("")
  );
}

/** تحويل HEX إلى RGB */
export function hexToRgb(hex: string): RGB {
  const clean = hex.replace("#", "");
  const full =
    clean.length === 3
      ? clean.split("").map((c) => c + c).join("")
      : clean;
  const num = parseInt(full, 16);
  return {
    r: (num >> 16) & 255,
    g: (num >> 8) & 255,
    b: num & 255,
  };
}

/** حساب السطوع النسبي (luminance) */
export function luminance({ r, g, b }: RGB): number {
  return (0.2126 * r + 0.7152 * g + 0.0722 * b) / 255;
}

/** المسافة اللونية بين لونين (لتحديد التشابه) */
export function colorDistance(a: RGB, b: RGB): number {
  return Math.sqrt(
    Math.pow(a.r - b.r, 2) + Math.pow(a.g - b.g, 2) + Math.pow(a.b - b.b, 2)
  );
}

/** مزج لونين */
export function mixColors(a: RGB, b: RGB, ratio = 0.5): RGB {
  return {
    r: Math.round(a.r * (1 - ratio) + b.r * ratio),
    g: Math.round(a.g * (1 - ratio) + b.g * ratio),
    b: Math.round(a.b * (1 - ratio) + b.b * ratio),
  };
}

/** تفتيح اللون */
export function lighten(color: RGB, amount: number): RGB {
  const hsl = rgbToHsl(color);
  return hslToRgb({ ...hsl, l: Math.min(100, hsl.l + amount) });
}

/** تغميق اللون */
export function darken(color: RGB, amount: number): RGB {
  const hsl = rgbToHsl(color);
  return hslToRgb({ ...hsl, l: Math.max(0, hsl.l - amount) });
}

/** ضبط التشبع */
export function saturate(color: RGB, amount: number): RGB {
  const hsl = rgbToHsl(color);
  return hslToRgb({ ...hsl, s: Math.max(0, Math.min(100, hsl.s + amount)) });
}

/** لون مكمل */
export function complementary(color: RGB): RGB {
  const hsl = rgbToHsl(color);
  return hslToRgb({ ...hsl, h: (hsl.h + 180) % 360 });
}

/** ألوان متناظرة */
export function analogous(color: RGB, angle = 30): RGB[] {
  const hsl = rgbToHsl(color);
  return [
    hslToRgb({ ...hsl, h: (hsl.h - angle + 360) % 360 }),
    color,
    hslToRgb({ ...hsl, h: (hsl.h + angle) % 360 }),
  ];
}

/** ألوان مثلثية */
export function triadic(color: RGB): RGB[] {
  const hsl = rgbToHsl(color);
  return [
    color,
    hslToRgb({ ...hsl, h: (hsl.h + 120) % 360 }),
    hslToRgb({ ...hsl, h: (hsl.h + 240) % 360 }),
  ];
}

/** لون تباين مناسب (أبيض أو أسود) للنص على خلفية معينة */
export function contrastColor(bg: RGB): RGB {
  return luminance(bg) > 0.55 ? { r: 10, g: 10, b: 15 } : { r: 250, g: 248, b: 240 };
}
