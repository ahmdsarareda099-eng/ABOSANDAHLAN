/**
 * نظام تخزين محلي باستخدام IndexedDB.
 * بديل لقاعدة البيانات عند النشر على استضافات ثابتة مثل InfinityFree
 * (التي لا تدعم Node.js أو PostgreSQL).
 *
 * يخزن الإعلانات محلياً في متصفح المستخدم، بما فيها الصور المصغّرة.
 */

const DB_NAME = "advaize";
const DB_VERSION = 1;
const STORE_NAME = "ads";

export interface LocalAd {
  id?: number;
  template: string;
  palette: string;
  headline: string | null;
  subtext: string | null;
  cta: string | null;
  aspect: string;
  productPosition: string;
  backgroundStyle: string;
  thumbnail: string | null;
  createdAt: string;
}

let dbPromise: Promise<IDBDatabase> | null = null;

/** فتح (أو إنشاء) قاعدة بيانات IndexedDB. */
function openDB(): Promise<IDBDatabase> {
  if (dbPromise) return dbPromise;
  dbPromise = new Promise((resolve, reject) => {
    const request = indexedDB.open(DB_NAME, DB_VERSION);
    request.onerror = () => reject(request.error);
    request.onsuccess = () => resolve(request.result);
    request.onupgradeneeded = () => {
      const db = request.result;
      if (!db.objectStoreNames.contains(STORE_NAME)) {
        const store = db.createObjectStore(STORE_NAME, {
          keyPath: "id",
          autoIncrement: true,
        });
        store.createIndex("createdAt", "createdAt", { unique: false });
      }
    };
  });
  return dbPromise;
}

/** حفظ إعلان جديد. */
export async function saveAdLocal(ad: Omit<LocalAd, "id" | "createdAt">): Promise<LocalAd> {
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(STORE_NAME, "readwrite");
    const store = tx.objectStore(STORE_NAME);
    const record: LocalAd = {
      ...ad,
      createdAt: new Date().toISOString(),
    };
    const request = store.add(record);
    request.onsuccess = () => {
      record.id = request.result as number;
      resolve(record);
    };
    request.onerror = () => reject(request.error);
  });
}

/** استرجاع أحدث الإعلانات (حتى limit). */
export async function getAdsLocal(limit = 12): Promise<LocalAd[]> {
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(STORE_NAME, "readonly");
    const store = tx.objectStore(STORE_NAME);
    const index = store.index("createdAt");
    const request = index.openCursor(null, "prev");
    const results: LocalAd[] = [];
    request.onsuccess = () => {
      const cursor = request.result;
      if (cursor && results.length < limit) {
        results.push(cursor.value as LocalAd);
        cursor.continue();
      } else {
        resolve(results);
      }
    };
    request.onerror = () => reject(request.error);
  });
}

/** حذف إعلان. */
export async function deleteAdLocal(id: number): Promise<void> {
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(STORE_NAME, "readwrite");
    const store = tx.objectStore(STORE_NAME);
    const request = store.delete(id);
    request.onsuccess = () => resolve();
    request.onerror = () => reject(request.error);
  });
}

/** حذف كل الإعلانات. */
export async function clearAdsLocal(): Promise<void> {
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(STORE_NAME, "readwrite");
    const store = tx.objectStore(STORE_NAME);
    const request = store.clear();
    request.onsuccess = () => resolve();
    request.onerror = () => reject(request.error);
  });
}

/** التحقق من توفر IndexedDB. */
export function isIndexedDBAvailable(): boolean {
  return typeof indexedDB !== "undefined";
}
