/**
 * قوالب تصميم الإعلانات.
 * كل قالب يحدد أسلوب التكوين: الموضع، الزخارف، طبقات الخلفية.
 */

export type TemplateId =
  | "minimal"
  | "luxury"
  | "vibrant"
  | "corporate"
  | "editorial"
  | "neon";

export interface Template {
  id: TemplateId;
  name: string;
  nameEn: string;
  description: string;
  icon: string;
}

export const TEMPLATES: Template[] = [
  {
    id: "minimal",
    name: "مينيمال",
    nameEn: "Minimal",
    description: "تركيز على المنتج بخلفية نظيفة ونص أنيق",
    icon: "◯",
  },
  {
    id: "luxury",
    name: "فاخر",
    nameEn: "Luxury",
    description: "لمسات ذهبية وإطارات راقية للعلامات الفاخرة",
    icon: "◆",
  },
  {
    id: "vibrant",
    name: "نابض",
    nameEn: "Vibrant",
    description: "ألوان جريئة وأشكال حيوية للإعلانات العصرية",
    icon: "✦",
  },
  {
    id: "corporate",
    name: "احترافي",
    nameEn: "Corporate",
    description: "تصميم موثوق للشركات والمنتجات الرسمية",
    icon: "▣",
  },
  {
    id: "editorial",
    name: "مجلة",
    nameEn: "Editorial",
    description: "تكوين صحفي بصري قوي كالمجلات العالمية",
    icon: "▤",
  },
  {
    id: "neon",
    name: "نيون",
    nameEn: "Neon",
    description: "توهج نيوني للألعاب والتطبيقات التقنية",
    icon: "✧",
  },
];

export function getTemplate(id: string): Template {
  return TEMPLATES.find((t) => t.id === id) ?? TEMPLATES[0];
}
