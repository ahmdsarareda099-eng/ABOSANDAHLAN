import { useCallback, useEffect, useRef, useState } from "react";
import type { ImageAnalysis } from "@/lib/image-analysis";
import { analyzeImage } from "@/lib/image-analysis";
import type { AdConfig, AspectRatio, BackgroundStyle, ProductPosition } from "@/lib/ad-renderer";
import { renderAd } from "@/lib/ad-renderer";
import { getPalette, generateSmartPalette, PALETTES } from "@/lib/palettes";
import type { Palette } from "@/lib/palettes";
import type { TemplateId } from "@/lib/templates";

export interface AdState {
  template: TemplateId;
  paletteId: string;
  headline: string;
  subtext: string;
  cta: string;
  brand: string;
  aspect: AspectRatio;
  productPosition: ProductPosition;
  backgroundStyle: BackgroundStyle;
  showPrice: boolean;
  price: string;
}

const DEFAULT_STATE: AdState = {
  template: "luxury",
  paletteId: "midnight-gold",
  headline: "تجربة فاخرة لا تُنسى",
  subtext: "صُنع بعناية فائقة ليمنحك التميّز في كل تفصيلة",
  cta: "اكتشف الآن",
  brand: "BRAND",
  aspect: "square",
  productPosition: "center",
  backgroundStyle: "gradient",
  showPrice: false,
  price: "٤٩٩ ر.س",
};

export function useAdGenerator() {
  const [state, setState] = useState<AdState>(DEFAULT_STATE);
  const [productImg, setProductImg] = useState<HTMLImageElement | null>(null);
  const [productSrc, setProductSrc] = useState<string | null>(null);
  const [analysis, setAnalysis] = useState<ImageAnalysis | null>(null);
  const [smartPalette, setSmartPalette] = useState<Palette | null>(null);
  const [palette, setPalette] = useState<Palette>(PALETTES[0]);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [isRendering, setIsRendering] = useState(false);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [isAnalyzingDone, setIsAnalyzingDone] = useState(false);

  /** تحميل صورة المنتج وتحليلها. */
  const loadProductImage = useCallback(async (file: File | string) => {
    setIsAnalyzing(true);
    setIsAnalyzingDone(false);
    setAnalysis(null);

    const src = typeof file === "string" ? file : URL.createObjectURL(file);
    setProductSrc(src);

    const img = new Image();
    //尝试 تفعيل CORS لصور الشبكة، مع fallback للصور المحلية
    if (typeof file === "string") {
      img.crossOrigin = "anonymous";
    }
    await new Promise<void>((resolve, reject) => {
      img.onload = () => resolve();
      img.onerror = () => reject(new Error("load_failed"));
      img.src = src;
    });
    setProductImg(img);

    // التحليل على canvas مصغّر
    const tmpCanvas = document.createElement("canvas");
    const maxDim = 200;
    const ratio = img.naturalWidth / img.naturalHeight || 1;
    if (ratio > 1) {
      tmpCanvas.width = maxDim;
      tmpCanvas.height = Math.round(maxDim / ratio);
    } else {
      tmpCanvas.height = maxDim;
      tmpCanvas.width = Math.round(maxDim * ratio);
    }
    const tmpCtx = tmpCanvas.getContext("2d", { willReadFrequently: true })!;
    tmpCtx.drawImage(img, 0, 0, tmpCanvas.width, tmpCanvas.height);

    let result: ImageAnalysis | null = null;
    try {
      const imageData = tmpCtx.getImageData(0, 0, tmpCanvas.width, tmpCanvas.height);
      // تأخير بسيط لإظهار حالة "التحليل" بصرياً
      await new Promise((r) => setTimeout(r, 600));
      result = analyzeImage(imageData);
    } catch (e) {
      // قد يفشل getImageData بسبب قيود CORS على صور الشبكة — نكمل بدون تحليل
      console.warn("Image analysis skipped due to CORS:", e);
      await new Promise((r) => setTimeout(r, 600));
    }

    if (result) {
      setAnalysis(result);
      const sp = generateSmartPalette(result.primaryColor, result.brightness);
      setSmartPalette(sp);
      setPalette(sp);
      setState((s) => ({ ...s, paletteId: "smart-auto" }));
    } else {
      // fallback: استخدام لوحة Midnight Gold
      setPalette(PALETTES[0]);
      setState((s) => ({ ...s, paletteId: "midnight-gold" }));
    }

    setIsAnalyzing(false);
    setIsAnalyzingDone(true);
  }, []);

  /** تحديث جزء من الحالة. */
  const update = useCallback(<K extends keyof AdState>(key: K, value: AdState[K]) => {
    setState((s) => ({ ...s, [key]: value }));
  }, []);

  /** تغيير لوحة الألوان. */
  const changePalette = useCallback((id: string) => {
    setState((s) => ({ ...s, paletteId: id }));
    if (id === "smart-auto" && smartPalette) {
      setPalette(smartPalette);
    } else {
      setPalette(getPalette(id));
    }
  }, [smartPalette]);

  /** توليد الاقتراحات التلقائية للنصوص. */
  const suggestCopy = useCallback(() => {
    if (!analysis) return;
    const suggestions = [
      {
        headline: "جودة تتجاوز التوقعات",
        subtext: "تصميم عصري يجمع بين الأناقة والوظيفة",
        cta: "تسوّق الآن",
      },
      {
        headline: "التميّز في كل تفصيلة",
        subtext: "اكتشف منتجاً صُنع ليمنحك تجربة استثنائية",
        cta: "اطلب اليوم",
      },
      {
        headline: "رفاهية لا تُضاهى",
        subtext: "منتج فريد يعكس ذوقك الرفيع",
        cta: "اكتشف المزيد",
      },
    ];
    const pick = suggestions[Math.floor(Math.random() * suggestions.length)];
    setState((s) => ({ ...s, ...pick }));
  }, [analysis]);

  /** الرسم على canvas عند تغيّر أي إعداد. */
  useEffect(() => {
    if (!productImg || !canvasRef.current) return;
    setIsRendering(true);

    // استخدام requestAnimationFrame لتجنب تجميد الواجهة
    const raf = requestAnimationFrame(() => {
      if (!canvasRef.current || !productImg) {
        setIsRendering(false);
        return;
      }
      const config: AdConfig = {
        template: state.template,
        palette,
        headline: state.headline,
        subtext: state.subtext,
        cta: state.cta,
        brand: state.brand,
        aspect: state.aspect,
        productPosition: state.productPosition,
        backgroundStyle: state.backgroundStyle,
        showPrice: state.showPrice,
        price: state.price,
      };
      const ctx = canvasRef.current.getContext("2d")!;
      renderAd(ctx, productImg, analysis, config);
      setIsRendering(false);
    });

    return () => cancelAnimationFrame(raf);
  }, [state, palette, productImg, analysis]);

  /** تحميل الإعلان كملف PNG. */
  const download = useCallback(async () => {
    if (!canvasRef.current) return;
    const canvas = canvasRef.current;
    const blob = await new Promise<Blob>((resolve) => {
      canvas.toBlob((b) => resolve(b || new Blob()), "image/png");
    });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `ad-${state.template}-${state.aspect}-${Date.now()}.png`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  }, [state.template, state.aspect]);

  /** حفظ الإعلان محلياً (IndexedDB) مع صورة مصغّرة. */
  const saveAd = useCallback(async () => {
    if (!canvasRef.current) return null;
    // صورة مصغرة صغيرة
    const thumb = document.createElement("canvas");
    const thumbW = 320;
    const ratio = canvasRef.current.height / canvasRef.current.width;
    thumb.width = thumbW;
    thumb.height = Math.round(thumbW * ratio);
    const thumbCtx = thumb.getContext("2d")!;
    thumbCtx.drawImage(canvasRef.current, 0, 0, thumb.width, thumb.height);
    const thumbnail = thumb.toDataURL("image/jpeg", 0.7);

    // استخدام التخزين المحلي (IndexedDB) — يعمل على استضافات ثابتة مثل InfinityFree
    const { saveAdLocal } = await import("@/lib/localStore");
    const saved = await saveAdLocal({
      template: state.template,
      palette: state.paletteId,
      headline: state.headline,
      subtext: state.subtext,
      cta: state.cta,
      aspect: state.aspect,
      productPosition: state.productPosition,
      backgroundStyle: state.backgroundStyle,
      thumbnail,
    });
    return { item: saved };
  }, [state, analysis]);

  /** إعادة الضبط. */
  const reset = useCallback(() => {
    setState(DEFAULT_STATE);
    setProductImg(null);
    setProductSrc(null);
    setAnalysis(null);
    setSmartPalette(null);
    setPalette(PALETTES[0]);
    setIsAnalyzingDone(false);
  }, []);

  return {
    state,
    update,
    palette,
    changePalette,
    smartPalette,
    loadProductImage,
    productImg,
    productSrc,
    analysis,
    isAnalyzing,
    isAnalyzingDone,
    isRendering,
    canvasRef,
    download,
    saveAd,
    suggestCopy,
    reset,
  };
}
