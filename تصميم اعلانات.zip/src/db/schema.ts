import { pgTable, serial, text, timestamp, jsonb } from "drizzle-orm/pg-core";

/**
 * سجل الإعلانات التي تم توليدها عبر المنصة.
 * كل صف يمثل إعلاناً واحداً مع بياناته الوصفية وصورة مصغّرة.
 */
export const ads = pgTable("ads", {
  id: serial("id").primaryKey(),
  template: text("template").notNull(),
  palette: text("palette").notNull(),
  headline: text("headline"),
  subtext: text("subtext"),
  cta: text("cta"),
  aspect: text("aspect").notNull(),
  productPosition: text("product_position").notNull().default("center"),
  backgroundStyle: text("background_style").notNull().default("gradient"),
  thumbnail: text("thumbnail"),
  meta: jsonb("meta").default({}),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export type Ad = typeof ads.$inferSelect;
export type NewAd = typeof ads.$inferInsert;
