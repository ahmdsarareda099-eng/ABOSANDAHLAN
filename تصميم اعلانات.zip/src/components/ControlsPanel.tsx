"use client";

import type { AdState } from "@/hooks/useAdGenerator";
import { TEMPLATES } from "@/lib/templates";
import type { TemplateId } from "@/lib/templates";
import { PALETTES } from "@/lib/palettes";
import type { Palette } from "@/lib/palettes";
import { rgbToHex } from "@/lib/color";
import type { AspectRatio, BackgroundStyle, ProductPosition } from "@/lib/ad-renderer";

interface ControlsPanelProps {
  state: AdState;
  update: <K extends keyof AdState>(key: K, value: AdState[K]) => void;
  changePalette: (id: string) => void;
  smartPalette: Palette | null;
  onSuggestCopy: () => void;
}

const ASPECT_OPTIONS: { id: AspectRatio; label: string; icon: string }[] = [
  { id: "square", label: "مربّع", icon: "⬛" },
  { id: "story", label: "ستوري", icon: "▮" },
  { id: "landscape", label: "أفقي", icon: "▬" },
];

const BG_OPTIONS: { id: BackgroundStyle; label: string }[] = [
  { id: "gradient", label: "تدرج" },
  { id: "blur", label: "ضبابي" },
  { id: "solid", label: "لون واحد" },
  { id: "split", label: "منقسم" },
  { id: "pattern", label: "نمط" },
];

const POS_OPTIONS: { id: ProductPosition; label: string }[] = [
  { id: "center", label: "وسط" },
  { id: "left", label: "يسار" },
  { id: "right", label: "يمين" },
];

export function ControlsPanel({
  state,
  update,
  changePalette,
  smartPalette,
  onSuggestCopy,
}: ControlsPanelProps) {
  const allPalettes: Palette[] = smartPalette
    ? [smartPalette, ...PALETTES]
    : PALETTES;

  return (
    <div className="space-y-6">
      {/* القوالب */}
      <Section title="نمط الإعلان" icon="◆">
        <div className="grid grid-cols-3 gap-2">
          {TEMPLATES.map((t) => (
            <button
              key={t.id}
              type="button"
              onClick={() => update("template", t.id as TemplateId)}
              className={`group flex flex-col items-center gap-1.5 rounded-xl border p-3 transition-all ${
                state.template === t.id
                  ? "border-[#d4a574] bg-[#d4a574]/10"
                  : "border-white/10 bg-white/[0.02] hover:border-white/25 hover:bg-white/[0.05]"
              }`}
              title={t.description}
            >
              <span
                className={`text-xl transition-transform group-hover:scale-110 ${
                  state.template === t.id ? "text-[#d4a574]" : "text-slate-400"
                }`}
              >
                {t.icon}
              </span>
              <span
                className={`text-xs font-medium ${
                  state.template === t.id ? "text-[#d4a574]" : "text-slate-300"
                }`}
              >
                {t.name}
              </span>
            </button>
          ))}
        </div>
      </Section>

      {/* لوحات الألوان */}
      <Section title="لوحة الألوان" icon="●">
        <div className="grid grid-cols-2 gap-2">
          {allPalettes.map((p) => (
            <button
              key={p.id}
              type="button"
              onClick={() => changePalette(p.id)}
              className={`group flex items-center gap-2.5 rounded-xl border p-2.5 transition-all ${
                state.paletteId === p.id
                  ? "border-[#d4a574] bg-[#d4a574]/10"
                  : "border-white/10 bg-white/[0.02] hover:border-white/25"
              }`}
            >
              <div className="flex overflow-hidden rounded-md ring-1 ring-white/10">
                <div className="h-7 w-3.5" style={{ background: rgbToHex(p.bg) }} />
                <div className="h-7 w-3.5" style={{ background: rgbToHex(p.bg2) }} />
                <div className="h-7 w-3.5" style={{ background: rgbToHex(p.accent) }} />
                <div className="h-7 w-3.5" style={{ background: rgbToHex(p.accent2) }} />
              </div>
              <div className="flex-1 text-right">
                <p className="text-xs font-medium text-white">{p.name}</p>
                {p.id === "smart-auto" && (
                  <p className="text-[10px] text-[#d4a574]">★ مستخرج تلقائياً</p>
                )}
              </div>
            </button>
          ))}
        </div>
      </Section>

      {/* النصوص */}
      <Section title="النصوص الإعلانية" icon="✎">
        <div className="space-y-3">
          <div>
            <Label>العلامة التجارية</Label>
            <Input
              value={state.brand}
              onChange={(v) => update("brand", v)}
              placeholder="BRAND"
            />
          </div>
          <div>
            <Label>العنوان الرئيسي</Label>
            <Input
              value={state.headline}
              onChange={(v) => update("headline", v)}
              placeholder="عنوان جذاب..."
            />
          </div>
          <div>
            <Label>النص الفرعي</Label>
            <Textarea
              value={state.subtext}
              onChange={(v) => update("subtext", v)}
              placeholder="وصف مختصر..."
            />
          </div>
          <div>
            <Label>زر الإجراء (CTA)</Label>
            <Input
              value={state.cta}
              onChange={(v) => update("cta", v)}
              placeholder="اكتشف الآن"
            />
          </div>
          <button
            type="button"
            onClick={onSuggestCopy}
            className="flex w-full items-center justify-center gap-2 rounded-xl border border-[#7c5cff]/30 bg-[#7c5cff]/10 px-4 py-2.5 text-sm font-medium text-[#c4b5fd] transition hover:bg-[#7c5cff]/20"
          >
            <svg className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
              <path strokeLinecap="round" strokeLinejoin="round" d="M9.813 15.904L9 18.75l-.813-2.846a4.5 4.5 0 00-3.09-3.09L2.25 12l2.846-.813a4.5 4.5 0 003.09-3.09L9 5.25l.813 2.846a4.5 4.5 0 003.09 3.09L15.75 12l-2.846.813a4.5 4.5 0 00-3.09 3.09z" />
            </svg>
            اقترح نصوصاً بالذكاء الاصطناعي
          </button>
        </div>
      </Section>

      {/* السعر */}
      <Section title="شارة السعر" icon="$">
        <div className="flex items-center gap-3">
          <Toggle
            checked={state.showPrice}
            onChange={(v) => update("showPrice", v)}
          />
          <span className="text-sm text-slate-300">إظهار السعر</span>
        </div>
        {state.showPrice && (
          <div className="mt-3">
            <Input
              value={state.price}
              onChange={(v) => update("price", v)}
              placeholder="٤٩٩ ر.س"
            />
          </div>
        )}
      </Section>

      {/* الحجم */}
      <Section title="حجم التصدير" icon="⬚">
        <div className="grid grid-cols-3 gap-2">
          {ASPECT_OPTIONS.map((opt) => (
            <button
              key={opt.id}
              type="button"
              onClick={() => update("aspect", opt.id)}
              className={`flex flex-col items-center gap-1.5 rounded-xl border p-3 transition-all ${
                state.aspect === opt.id
                  ? "border-[#d4a574] bg-[#d4a574]/10"
                  : "border-white/10 bg-white/[0.02] hover:border-white/25"
              }`}
            >
              <span
                className={`text-lg ${
                  state.aspect === opt.id ? "text-[#d4a574]" : "text-slate-400"
                }`}
              >
                {opt.icon}
              </span>
              <span className="text-xs font-medium text-slate-200">{opt.label}</span>
            </button>
          ))}
        </div>
      </Section>

      {/* الخلفية */}
      <Section title="نمط الخلفية" icon="▦">
        <div className="grid grid-cols-5 gap-1.5">
          {BG_OPTIONS.map((opt) => (
            <button
              key={opt.id}
              type="button"
              onClick={() => update("backgroundStyle", opt.id)}
              className={`rounded-lg border px-2 py-2 text-xs font-medium transition ${
                state.backgroundStyle === opt.id
                  ? "border-[#d4a574] bg-[#d4a574]/10 text-[#d4a574]"
                  : "border-white/10 bg-white/[0.02] text-slate-300 hover:border-white/25"
              }`}
            >
              {opt.label}
            </button>
          ))}
        </div>
      </Section>

      {/* موضع المنتج */}
      <Section title="موضع المنتج" icon="⊙">
        <div className="grid grid-cols-3 gap-2">
          {POS_OPTIONS.map((opt) => (
            <button
              key={opt.id}
              type="button"
              onClick={() => update("productPosition", opt.id)}
              className={`rounded-xl border p-3 transition ${
                state.productPosition === opt.id
                  ? "border-[#d4a574] bg-[#d4a574]/10 text-[#d4a574]"
                  : "border-white/10 bg-white/[0.02] text-slate-300 hover:border-white/25"
              }`}
            >
              <div className="mb-1.5 flex justify-center">
                <div className="relative h-8 w-12 rounded border border-current/30">
                  <div
                    className="absolute top-1 h-6 w-4 rounded-sm bg-current/60"
                    style={{
                      right: opt.id === "left" ? "auto" : opt.id === "right" ? "4px" : "50%",
                      left: opt.id === "left" ? "4px" : opt.id === "right" ? "auto" : "50%",
                      transform: opt.id === "center" ? "translateX(-50%)" : "none",
                    }}
                  />
                </div>
              </div>
              <span className="text-xs font-medium">{opt.label}</span>
            </button>
          ))}
        </div>
      </Section>
    </div>
  );
}

function Section({
  title,
  icon,
  children,
}: {
  title: string;
  icon: string;
  children: React.ReactNode;
}) {
  return (
    <div className="rounded-2xl border border-white/10 bg-white/[0.02] p-4">
      <div className="mb-3 flex items-center gap-2">
        <span className="text-sm text-[#d4a574]">{icon}</span>
        <h3 className="text-sm font-bold text-white">{title}</h3>
      </div>
      {children}
    </div>
  );
}

function Label({ children }: { children: React.ReactNode }) {
  return <label className="mb-1.5 block text-xs text-slate-400">{children}</label>;
}

function Input({
  value,
  onChange,
  placeholder,
}: {
  value: string;
  onChange: (v: string) => void;
  placeholder?: string;
}) {
  return (
    <input
      type="text"
      value={value}
      placeholder={placeholder}
      onChange={(e) => onChange(e.target.value)}
      className="w-full rounded-xl border border-white/10 bg-black/30 px-3 py-2 text-sm text-white placeholder:text-slate-500 focus:border-[#d4a574]/50 focus:outline-none focus:ring-1 focus:ring-[#d4a574]/30"
    />
  );
}

function Textarea({
  value,
  onChange,
  placeholder,
}: {
  value: string;
  onChange: (v: string) => void;
  placeholder?: string;
}) {
  return (
    <textarea
      value={value}
      placeholder={placeholder}
      rows={2}
      onChange={(e) => onChange(e.target.value)}
      className="w-full resize-none rounded-xl border border-white/10 bg-black/30 px-3 py-2 text-sm text-white placeholder:text-slate-500 focus:border-[#d4a574]/50 focus:outline-none focus:ring-1 focus:ring-[#d4a574]/30"
    />
  );
}

function Toggle({
  checked,
  onChange,
}: {
  checked: boolean;
  onChange: (v: boolean) => void;
}) {
  return (
    <button
      type="button"
      role="switch"
      aria-checked={checked}
      onClick={() => onChange(!checked)}
      className={`relative h-6 w-11 rounded-full transition ${
        checked ? "bg-[#d4a574]" : "bg-white/15"
      }`}
    >
      <span
        className={`absolute top-0.5 h-5 w-5 rounded-full bg-white shadow transition-transform ${
          checked ? "right-0.5" : "right-5"
        }`}
      />
    </button>
  );
}
