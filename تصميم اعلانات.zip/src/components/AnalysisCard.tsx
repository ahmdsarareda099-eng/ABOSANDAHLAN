"use client";

import type { ImageAnalysis } from "@/lib/image-analysis";
import { rgbToHex } from "@/lib/color";

interface AnalysisCardProps {
  analysis: ImageAnalysis;
  isAnalyzing: boolean;
}

export function AnalysisCard({ analysis, isAnalyzing }: AnalysisCardProps) {
  if (isAnalyzing) {
    return (
      <div className="rounded-2xl border border-white/10 bg-white/[0.03] p-5">
        <div className="mb-4 flex items-center gap-2">
          <div className="h-2 w-2 animate-pulse rounded-full bg-[#d4a574]" />
          <span className="text-sm font-medium text-[#d4a574]">جارٍ تحليل الصورة...</span>
        </div>
        <div className="space-y-3">
          {[1, 2, 3, 4].map((i) => (
            <div key={i} className="h-3 overflow-hidden rounded bg-white/5">
              <div className="h-full w-1/2 shimmer" />
            </div>
          ))}
        </div>
      </div>
    );
  }

  const primaryHex = rgbToHex(analysis.primaryColor);
  const bgHex = rgbToHex(analysis.backgroundColor);
  const brightnessPct = Math.round(analysis.brightness * 100);
  const contrastPct = Math.round(analysis.contrast * 100);

  return (
    <div className="rounded-2xl border border-white/10 bg-white/[0.03] p-5">
      <div className="mb-4 flex items-center gap-2">
        <svg className="h-4 w-4 text-[#d4a574]" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
          <path strokeLinecap="round" strokeLinejoin="round" d="M9.813 15.904L9 18.75l-.813-2.846a4.5 4.5 0 00-3.09-3.09L2.25 12l2.846-.813a4.5 4.5 0 003.09-3.09L9 5.25l.813 2.846a4.5 4.5 0 003.09 3.09L15.75 12l-2.846.813a4.5 4.5 0 00-3.09 3.09z" />
        </svg>
        <h3 className="text-sm font-bold text-white">تحليل الذكاء الاصطناعي</h3>
      </div>

      {/* الألوان المستخرجة */}
      <div className="mb-4">
        <p className="mb-2 text-xs text-slate-400">الألوان المهيمنة</p>
        <div className="flex gap-1.5">
          {analysis.dominantColors.map((c, i) => (
            <div
              key={i}
              className="h-8 flex-1 rounded-md ring-1 ring-white/10"
              style={{ background: rgbToHex(c) }}
              title={rgbToHex(c)}
            />
          ))}
        </div>
      </div>

      {/* الشبكة الإحصائية */}
      <div className="grid grid-cols-2 gap-3">
        <Stat label="اللون الأساسي" value={primaryHex}>
          <div
            className="h-6 w-6 rounded-md ring-1 ring-white/20"
            style={{ background: primaryHex }}
          />
        </Stat>
        <Stat label="الخلفية الأصلية" value={bgHex}>
          <div
            className="h-6 w-6 rounded-md ring-1 ring-white/20"
            style={{ background: bgHex }}
          />
        </Stat>
        <Stat label="السطوع" value={`${brightnessPct}%`}>
          <div className="flex h-6 items-center gap-0.5">
            {[...Array(5)].map((_, i) => (
              <div
                key={i}
                className="h-2 w-1.5 rounded-sm"
                style={{
                  background: i < Math.round(brightnessPct / 20) ? "#d4a574" : "rgba(255,255,255,0.1)",
                }}
              />
            ))}
          </div>
        </Stat>
        <Stat label="التباين" value={`${contrastPct}%`}>
          <div className="flex h-6 items-center gap-0.5">
            {[...Array(5)].map((_, i) => (
              <div
                key={i}
                className="h-2 w-1.5 rounded-sm"
                style={{
                  background: i < Math.round(contrastPct / 20) ? "#7c5cff" : "rgba(255,255,255,0.1)",
                }}
              />
            ))}
          </div>
        </Stat>
      </div>

      {/* مركز الثقل البصري */}
      <div className="mt-4 rounded-xl bg-black/20 p-3">
        <div className="flex items-center justify-between">
          <span className="text-xs text-slate-400">مركز المنتج البصري</span>
          <span className="font-mono text-xs text-[#d4a574]">
            X:{Math.round(analysis.centroid.x * 100)}% · Y:{Math.round(analysis.centroid.y * 100)}%
          </span>
        </div>
        <div className="relative mt-2 h-16 overflow-hidden rounded-lg bg-white/5">
          <div
            className="absolute h-3 w-3 -translate-x-1/2 -translate-y-1/2 rounded-full bg-[#d4a574] shadow-[0_0_12px_#d4a574]"
            style={{
              left: `${analysis.centroid.x * 100}%`,
              top: `${analysis.centroid.y * 100}%`,
            }}
          />
          <div className="absolute inset-0 grid grid-cols-3 grid-rows-3">
            {[...Array(9)].map((_, i) => (
              <div key={i} className="border border-white/5" />
            ))}
          </div>
        </div>
      </div>

      {/* مؤشر نظافة الخلفية */}
      <div className="mt-3 flex items-center justify-between rounded-xl bg-black/20 p-3">
        <span className="text-xs text-slate-400">نظافة الخلفية الأصلية</span>
        <div className="flex items-center gap-2">
          <div className="h-1.5 w-20 overflow-hidden rounded-full bg-white/10">
            <div
              className="h-full rounded-full bg-gradient-to-r from-[#ff5c8a] to-[#10b981]"
              style={{ width: `${Math.round(analysis.backgroundCleanliness * 100)}%` }}
            />
          </div>
          <span className="font-mono text-xs text-slate-300">
            {Math.round(analysis.backgroundCleanliness * 100)}%
          </span>
        </div>
      </div>
    </div>
  );
}

function Stat({
  label,
  value,
  children,
}: {
  label: string;
  value: string;
  children?: React.ReactNode;
}) {
  return (
    <div className="rounded-xl bg-black/20 p-3">
      <p className="mb-1.5 text-xs text-slate-400">{label}</p>
      <div className="flex items-center gap-2">
        {children}
        <span className="font-mono text-xs text-white">{value}</span>
      </div>
    </div>
  );
}
