"use client";

import { useCallback, useRef, useState } from "react";

interface UploaderProps {
  onImage: (file: File) => void;
  samples?: { url: string; label: string; emoji: string }[];
  onSample?: (url: string) => void;
  disabled?: boolean;
}

export function Uploader({ onImage, onSample, samples, disabled }: UploaderProps) {
  const [isDragging, setIsDragging] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);

  const handleFile = useCallback(
    (file: File) => {
      if (!file.type.startsWith("image/")) return;
      onImage(file);
    },
    [onImage]
  );

  const handleDrop = useCallback(
    (e: React.DragEvent) => {
      e.preventDefault();
      setIsDragging(false);
      if (disabled) return;
      const file = e.dataTransfer.files[0];
      if (file) handleFile(file);
    },
    [handleFile, disabled]
  );

  return (
    <div className="relative">
      <div
        onDragOver={(e) => {
          e.preventDefault();
          if (!disabled) setIsDragging(true);
        }}
        onDragLeave={() => setIsDragging(false)}
        onDrop={handleDrop}
        onClick={() => !disabled && inputRef.current?.click()}
        className={`group relative flex cursor-pointer flex-col items-center justify-center gap-6 rounded-3xl border-2 border-dashed p-12 transition-all duration-300 ${
          isDragging
            ? "border-[#d4a574] bg-[#d4a574]/5 scale-[1.01]"
            : "border-white/15 hover:border-[#d4a574]/50 hover:bg-white/[0.02]"
        } ${disabled ? "pointer-events-none opacity-50" : ""}`}
        style={{ minHeight: 320 }}
      >
        <input
          ref={inputRef}
          type="file"
          accept="image/*"
          className="hidden"
          onChange={(e) => {
            const file = e.target.files?.[0];
            if (file) handleFile(file);
          }}
        />

        {/* أيقونة الرفع */}
        <div className="relative">
          <div className="absolute inset-0 -z-10 rounded-full bg-[#d4a574]/20 blur-2xl" />
          <div className="flex h-20 w-20 items-center justify-center rounded-2xl bg-gradient-to-br from-[#d4a574]/20 to-[#7c5cff]/10 ring-1 ring-[#d4a574]/30 transition-transform duration-300 group-hover:scale-110 group-hover:rotate-3">
            <svg className="h-9 w-9 text-[#d4a574]" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.8}>
              <path strokeLinecap="round" strokeLinejoin="round" d="M3 16.5v2.25A2.25 2.25 0 005.25 21h13.5A2.25 2.25 0 0021 18.75V16.5m-13.5-9L12 3m0 0l4.5 4.5M12 3v13.5" />
            </svg>
          </div>
        </div>

        <div className="text-center">
          <h3 className="text-xl font-bold text-white">ارفع صورة منتجك</h3>
          <p className="mt-2 text-sm text-slate-400">
            اسحب وأفلت الصورة هنا، أو انقر للاختيار
          </p>
          <p className="mt-1 text-xs text-slate-500">PNG · JPG · WEBP — حتى 10MB</p>
        </div>

        {/* شريط الفاصل */}
        {samples && samples.length > 0 && (
          <>
            <div className="flex w-full max-w-xs items-center gap-3">
              <div className="h-px flex-1 bg-white/10" />
              <span className="text-xs text-slate-500">أو جرّب عيّنة</span>
              <div className="h-px flex-1 bg-white/10" />
            </div>

            <div className="flex flex-wrap justify-center gap-2">
              {samples.map((s) => (
                <button
                  key={s.url}
                  type="button"
                  onClick={(e) => {
                    e.stopPropagation();
                    onSample?.(s.url);
                  }}
                  className="group flex items-center gap-2 rounded-full border border-white/15 bg-white/5 px-3 py-2 text-xs font-medium text-slate-200 transition hover:border-[#d4a574]/50 hover:bg-[#d4a574]/10 hover:text-[#d4a574]"
                >
                  <span className="text-base">{s.emoji}</span>
                  {s.label}
                </button>
              ))}
            </div>
          </>
        )}
      </div>
    </div>
  );
}
