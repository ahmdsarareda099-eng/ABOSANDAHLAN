"use client";

import { useState } from "react";
import { useAdGenerator } from "@/hooks/useAdGenerator";
import { Uploader } from "./Uploader";
import { AnalysisCard } from "./AnalysisCard";
import { ControlsPanel } from "./ControlsPanel";
import { PreviewCanvas } from "./PreviewCanvas";
import { Gallery } from "./Gallery";

const SAMPLE_IMAGES = [
  {
    url: "https://images.pexels.com/photos/16722498/pexels-photo-16722498.jpeg?auto=compress&cs=tinysrgb&dpr=2&w=940",
    label: "عطر فاخر",
    emoji: "🧴",
  },
  {
    url: "https://images.pexels.com/photos/16722501/pexels-photo-16722501.jpeg?auto=compress&cs=tinysrgb&dpr=2&w=940",
    label: "عطر ذهبي",
    emoji: "🌸",
  },
  {
    url: "https://images.pexels.com/photos/3750640/pexels-photo-3750640.jpeg?auto=compress&cs=tinysrgb&dpr=2&w=940",
    label: "مستحضرات",
    emoji: "💄",
  },
];

export function AdGenerator() {
  const gen = useAdGenerator();
  const [saved, setSaved] = useState(false);
  const [saving, setSaving] = useState(false);
  const [refreshKey, setRefreshKey] = useState(0);
  const [showGallery, setShowGallery] = useState(false);

  const hasProduct = !!gen.productImg;

  const handleSave = async () => {
    setSaving(true);
    try {
      await gen.saveAd();
      setSaved(true);
      setRefreshKey((k) => k + 1);
      setTimeout(() => setSaved(false), 2500);
    } catch (e) {
      console.error(e);
    } finally {
      setSaving(false);
    }
  };

  const handleReset = () => {
    gen.reset();
    setSaved(false);
  };

  return (
    <div className="aurora-bg min-h-screen">
      <div className="grid-overlay pointer-events-none fixed inset-0 -z-10" />

      {/* الهيدر */}
      <header className="sticky top-0 z-30 border-b border-white/5 bg-[#0a0a0f]/70 backdrop-blur-xl">
        <div className="mx-auto flex max-w-7xl items-center justify-between px-6 py-4">
          <div className="flex items-center gap-3">
            <div className="relative flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-br from-[#d4a574] to-[#7c5cff]">
              <svg className="h-5 w-5 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2.5}>
                <path strokeLinecap="round" strokeLinejoin="round" d="M9.813 15.904L9 18.75l-.813-2.846a4.5 4.5 0 00-3.09-3.09L2.25 12l2.846-.813a4.5 4.5 0 003.09-3.09L9 5.25l.813 2.846a4.5 4.5 0 003.09 3.09L15.75 12l-2.846.813a4.5 4.5 0 00-3.09 3.09z" />
              </svg>
              <div className="absolute -inset-1 -z-10 rounded-xl bg-[#d4a574]/30 blur-lg" />
            </div>
            <div>
              <h1 className="text-lg font-extrabold tracking-tight text-white">
                أَ<span className="text-gradient-gold">دفايز</span>
              </h1>
              <p className="text-[10px] text-slate-400">مولّد الإعلانات بالذكاء الاصطناعي</p>
            </div>
          </div>

          <nav className="flex items-center gap-2">
            <button
              type="button"
              onClick={() => setShowGallery((s) => !s)}
              className="flex items-center gap-2 rounded-full border border-white/10 bg-white/5 px-4 py-2 text-sm font-medium text-slate-200 transition hover:border-[#d4a574]/50 hover:text-[#d4a574]"
            >
              <svg className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                <path strokeLinecap="round" strokeLinejoin="round" d="M2.25 15.75l5.159-5.159a2.25 2.25 0 013.182 0l5.159 5.159m-1.5-1.5l1.409-1.409a2.25 2.25 0 013.182 0l2.909 2.909m-18 3.75h16.5a1.5 1.5 0 001.5-1.5V6a1.5 1.5 0 00-1.5-1.5H3.75A1.5 1.5 0 002.25 6v12a1.5 1.5 0 001.5 1.5z" />
              </svg>
              المعرض
            </button>
            {hasProduct && (
              <button
                type="button"
                onClick={handleReset}
                className="flex items-center gap-2 rounded-full border border-white/10 bg-white/5 px-4 py-2 text-sm font-medium text-slate-200 transition hover:border-[#ff5c8a]/50 hover:text-[#ff5c8a]"
              >
                <svg className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                  <path strokeLinecap="round" strokeLinejoin="round" d="M16.023 9.348h4.992v-.001M2.985 19.644v-4.992m0 0h4.992m-4.993 0l3.181 3.183a8.25 8.25 0 0013.803-3.7M4.031 9.865a8.25 8.25 0 0113.803-3.7l3.181 3.182m0-4.991v4.99" />
                </svg>
                صورة جديدة
              </button>
            )}
          </nav>
        </div>
      </header>

      {/* المحتوى الرئيسي */}
      <main className="mx-auto max-w-7xl px-6 py-8">
        {!hasProduct ? (
          <LandingView
            onImage={(f) => gen.loadProductImage(f)}
            onSample={(url) => gen.loadProductImage(url)}
          />
        ) : (
          <div className="grid grid-cols-1 gap-6 lg:grid-cols-[1fr_minmax(380px,440px)_minmax(380px,1fr)]">
            {/* العمود الأيمن: التحليل + المعرض */}
            <div className="order-2 space-y-6 lg:order-1">
              {gen.analysis && (
                <AnalysisCard analysis={gen.analysis} isAnalyzing={gen.isAnalyzing} />
              )}
              {gen.isAnalyzing && !gen.analysis && (
                <div className="rounded-2xl border border-white/10 bg-white/[0.03] p-5">
                  <div className="mb-4 flex items-center gap-2">
                    <div className="h-2 w-2 animate-pulse rounded-full bg-[#d4a574]" />
                    <span className="text-sm font-medium text-[#d4a574]">جارٍ تحليل الصورة...</span>
                  </div>
                  <div className="space-y-3">
                    {[1, 2, 3].map((i) => (
                      <div key={i} className="h-3 overflow-hidden rounded bg-white/5">
                        <div className="h-full w-1/2 shimmer" />
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* ملخص المنتج */}
              {gen.productSrc && (
                <div className="rounded-2xl border border-white/10 bg-white/[0.02] p-4">
                  <h3 className="mb-3 flex items-center gap-2 text-sm font-bold text-white">
                    <span className="text-[#d4a574]">◉</span> المنتج المرفوع
                  </h3>
                  <div className="overflow-hidden rounded-xl bg-black/30">
                    <img
                      src={gen.productSrc}
                      alt="المنتج"
                      className="h-32 w-full object-contain"
                    />
                  </div>
                </div>
              )}

              {showGallery && (
                <div className="rounded-2xl border border-white/10 bg-white/[0.02] p-4">
                  <h3 className="mb-3 flex items-center gap-2 text-sm font-bold text-white">
                    <span className="text-[#d4a574]">▤</span> الإعلانات المحفوظة
                  </h3>
                  <Gallery refreshKey={refreshKey} />
                </div>
              )}
            </div>

            {/* العمود الأوسط: المعاينة */}
            <div className="order-1 lg:order-2">
              <div className="sticky top-24">
                <PreviewCanvas
                  canvasRef={gen.canvasRef}
                  aspect={gen.state.aspect}
                  isRendering={gen.isRendering}
                  onDownload={gen.download}
                  onSave={handleSave}
                  saved={saved}
                  saving={saving}
                />
              </div>
            </div>

            {/* العمود الأيسر: لوحة التحكم */}
            <div className="order-3">
              <ControlsPanel
                state={gen.state}
                update={gen.update}
                changePalette={gen.changePalette}
                smartPalette={gen.smartPalette}
                onSuggestCopy={gen.suggestCopy}
              />
            </div>
          </div>
        )}
      </main>

      {/* الفوتر */}
      <footer className="mt-12 border-t border-white/5 py-6 text-center">
        <p className="text-xs text-slate-500">
          أَ<span className="text-[#d4a574]">دفايز</span> — مولّد الإعلانات بالذكاء الاصطناعي · يعمل بالكامل في متصفحك
        </p>
      </footer>
    </div>
  );
}

/**
 * صفحة الهبوط التي تُعرض قبل رفع صورة.
 */
function LandingView({
  onImage,
  onSample,
}: {
  onImage: (file: File) => void;
  onSample: (url: string) => void;
}) {
  return (
    <div className="mx-auto max-w-4xl">
      {/* عنوان البطل */}
      <div className="mb-12 text-center">
        <div className="mb-6 inline-flex items-center gap-2 rounded-full border border-[#d4a574]/30 bg-[#d4a574]/5 px-4 py-1.5 text-xs font-medium text-[#d4a574]">
          <span className="relative flex h-2 w-2">
            <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-[#d4a574] opacity-75" />
            <span className="relative inline-flex h-2 w-2 rounded-full bg-[#d4a574]" />
          </span>
          مدعوم بالذكاء الاصطناعي
        </div>
        <h1 className="text-[clamp(2.5rem,6vw,4.5rem)] font-extrabold leading-[1.05] tracking-tight text-white">
          صورة منتجك.
          <br />
          <span className="text-gradient-aurora">إعلان احترافي.</span>
        </h1>
        <p className="mx-auto mt-6 max-w-xl text-base leading-relaxed text-slate-400">
          ارفع صورة منتجك فقط، ودع الذكاء الاصطناعي يحلّل الألوان والشكل
          ليولّد إعلاناً احترافياً جاهزاً للنشر خلال ثوانٍ.
        </p>
      </div>

      {/* منطقة الرفع */}
      <Uploader
        onImage={onImage}
        onSample={onSample}
        samples={SAMPLE_IMAGES}
      />

      {/* الميزات */}
      <div className="mt-16 grid grid-cols-1 gap-4 sm:grid-cols-3">
        <Feature
          icon="🎨"
          title="تحليل ذكي للألوان"
          desc="يستخرج الألوان المهيمنة من منتجك ويبني لوحة متناغمة تلقائياً"
        />
        <Feature
          icon="⚡"
          title="توليد فوري"
          desc="6 قوالب احترافية و5 أنماط خلفية — كل شيء يُرسم لحظياً"
        />
        <Feature
          icon="📐"
          title="جاهز لكل المنصات"
          desc="صدّر بمقاسات مربّعة، ستوري، أو أفقية بضغطة واحدة"
        />
      </div>

      {/* خطوات العمل */}
      <div className="mt-16">
        <h2 className="mb-6 text-center text-sm font-bold uppercase tracking-widest text-slate-500">
          كيف يعمل؟
        </h2>
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
          <Step num="1" title="ارفع الصورة" desc="صورة المنتج فقط — أي خلفية، أي منتج" />
          <Step num="2" title="اختر النمط" desc="قالب + لوحة ألوان + نصوصك" />
          <Step num="3" title="حمّل الإعلان" desc="PNG عالي الدقة جاهز للنشر" />
        </div>
      </div>
    </div>
  );
}

function Feature({ icon, title, desc }: { icon: string; title: string; desc: string }) {
  return (
    <div className="rounded-2xl border border-white/10 bg-white/[0.02] p-5">
      <div className="mb-3 flex h-10 w-10 items-center justify-center rounded-xl bg-white/5 text-xl">
        {icon}
      </div>
      <h3 className="mb-1 text-sm font-bold text-white">{title}</h3>
      <p className="text-xs leading-relaxed text-slate-400">{desc}</p>
    </div>
  );
}

function Step({ num, title, desc }: { num: string; title: string; desc: string }) {
  return (
    <div className="relative rounded-2xl border border-white/10 bg-white/[0.02] p-5">
      <div className="absolute -top-3 right-5 flex h-7 w-7 items-center justify-center rounded-full bg-gradient-to-br from-[#d4a574] to-[#b8843d] text-sm font-bold text-[#1a1a22]">
        {num}
      </div>
      <h3 className="mb-1 text-sm font-bold text-white">{title}</h3>
      <p className="text-xs text-slate-400">{desc}</p>
    </div>
  );
}
