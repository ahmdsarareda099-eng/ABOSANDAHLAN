"use client";

import { useEffect, useState } from "react";

interface AdItem {
  id?: number;
  template: string;
  palette: string;
  headline: string | null;
  subtext: string | null;
  cta: string | null;
  aspect: string;
  thumbnail: string | null;
  createdAt: string;
}

interface GalleryProps {
  refreshKey: number;
  onSelect?: (item: AdItem) => void;
}

export function Gallery({ refreshKey, onSelect }: GalleryProps) {
  const [items, setItems] = useState<AdItem[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let cancelled = false;
    setLoading(true);
    import("@/lib/localStore")
      .then(({ getAdsLocal }) => getAdsLocal(12))
      .then((items) => {
        if (!cancelled) {
          setItems(items);
          setLoading(false);
        }
      })
      .catch(() => {
        if (!cancelled) {
          setItems([]);
          setLoading(false);
        }
      });
    return () => {
      cancelled = true;
    };
  }, [refreshKey]);

  if (loading) {
    return (
      <div className="grid grid-cols-2 gap-3 sm:grid-cols-3">
        {[1, 2, 3].map((i) => (
          <div key={i} className="aspect-square overflow-hidden rounded-xl bg-white/5">
            <div className="h-full w-full shimmer" />
          </div>
        ))}
      </div>
    );
  }

  if (items.length === 0) {
    return (
      <div className="rounded-2xl border border-dashed border-white/10 p-8 text-center">
        <div className="mx-auto mb-3 flex h-12 w-12 items-center justify-center rounded-full bg-white/5">
          <svg className="h-6 w-6 text-slate-500" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.5}>
            <path strokeLinecap="round" strokeLinejoin="round" d="M2.25 15.75l5.159-5.159a2.25 2.25 0 013.182 0l5.159 5.159m-1.5-1.5l1.409-1.409a2.25 2.25 0 013.182 0l2.909 2.909m-18 3.75h16.5a1.5 1.5 0 001.5-1.5V6a1.5 1.5 0 00-1.5-1.5H3.75A1.5 1.5 0 002.25 6v12a1.5 1.5 0 001.5 1.5zm10.5-11.25h.008v.008h-.008V8.25zm.375 0a.375.375 0 11-.75 0 .375.375 0 01.75 0z" />
          </svg>
        </div>
        <p className="text-sm text-slate-400">لا توجد إعلانات محفوظة بعد</p>
        <p className="mt-1 text-xs text-slate-500">أنشئ إعلاناً واحفظه ليظهر هنا</p>
      </div>
    );
  }

  return (
    <div className="grid grid-cols-2 gap-3 sm:grid-cols-3">
      {items.map((item) => (
        <button
          key={item.id}
          type="button"
          onClick={() => onSelect?.(item)}
          className="group relative overflow-hidden rounded-xl border border-white/10 bg-white/5 transition hover:border-[#d4a574]/50"
        >
          <div className="aspect-square overflow-hidden">
            {item.thumbnail ? (
              <img
                src={item.thumbnail}
                alt={item.headline ?? "إعلان"}
                className="h-full w-full object-cover transition-transform duration-300 group-hover:scale-105"
              />
            ) : (
              <div className="flex h-full items-center justify-center text-slate-600">
                <svg className="h-8 w-8" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1}>
                  <path strokeLinecap="round" strokeLinejoin="round" d="M2.25 15.75l5.159-5.159a2.25 2.25 0 013.182 0l5.159 5.159m-1.5-1.5l1.409-1.409a2.25 2.25 0 013.182 0l2.909 2.909m-18 3.75h16.5a1.5 1.5 0 001.5-1.5V6a1.5 1.5 0 00-1.5-1.5H3.75A1.5 1.5 0 002.25 6v12a1.5 1.5 0 001.5 1.5z" />
                </svg>
              </div>
            )}
          </div>
          <div className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-black/80 to-transparent p-2 text-right">
            <p className="truncate text-xs font-medium text-white">
              {item.headline ?? "بدون عنوان"}
            </p>
            <p className="text-[10px] text-slate-400">{item.template}</p>
          </div>
        </button>
      ))}
    </div>
  );
}
