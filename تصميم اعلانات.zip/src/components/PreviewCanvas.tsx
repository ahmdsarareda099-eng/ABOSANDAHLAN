"use client";

import { useRef } from "react";
import type { RefObject } from "react";
import type { AspectRatio } from "@/lib/ad-renderer";

interface PreviewCanvasProps {
  canvasRef: RefObject<HTMLCanvasElement | null>;
  aspect: AspectRatio;
  isRendering: boolean;
  onDownload: () => void;
  onSave: () => void;
  saved: boolean;
  saving: boolean;
}

export function PreviewCanvas({
  canvasRef,
  aspect,
  isRendering,
  onDownload,
  onSave,
  saved,
  saving,
}: PreviewCanvasProps) {
  const wrapRef = useRef<HTMLDivElement>(null);

  const aspectClass = {
    square: "aspect-square",
    story: "aspect-[9/16]",
    landscape: "aspect-[16/9]",
  }[aspect];

  return (
    <div className="flex flex-col gap-4">
      {/* معاينة Canvas */}
      <div ref={wrapRef} className="relative">
        <div
          className={`relative mx-auto overflow-hidden rounded-2xl ring-1 ring-white/10 ${aspectClass}`}
          style={{ maxHeight: "70vh" }}
        >
          <canvas
            ref={canvasRef}
            className="h-full w-full object-contain"
            style={{ background: "#0a0a0f" }}
          />

          {/* طبقة التوليد */}
          {isRendering && (
            <div className="absolute inset-0 flex items-center justify-center bg-black/40 backdrop-blur-sm">
              <div className="flex flex-col items-center gap-3">
                <div className="h-10 w-10 animate-spin-slow rounded-full border-2 border-white/20 border-t-[#d4a574]" />
                <span className="text-sm text-[#d4a574]">جارٍ التوليد...</span>
              </div>
            </div>
          )}

          {/* علامة مائية صغيرة */}
          <div className="pointer-events-none absolute bottom-3 left-3 rounded-full bg-black/40 px-2.5 py-1 text-[10px] text-white/70 backdrop-blur">
            ADVAIZE · AI
          </div>
        </div>
      </div>

      {/* أزرار الإجراءات */}
      <div className="grid grid-cols-2 gap-3">
        <button
          type="button"
          onClick={onDownload}
          className="group flex items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-[#d4a574] to-[#b8843d] px-4 py-3 text-sm font-bold text-[#1a1a22] transition hover:shadow-lg hover:shadow-[#d4a574]/30"
        >
          <svg className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2.5}>
            <path strokeLinecap="round" strokeLinejoin="round" d="M3 16.5v2.25A2.25 2.25 0 005.25 21h13.5A2.25 2.25 0 0021 18.75V16.5M16.5 12L12 16.5m0 0L7.5 12m4.5 4.5V3" />
          </svg>
          تحميل الإعلان
        </button>
        <button
          type="button"
          onClick={onSave}
          disabled={saving || saved}
          className={`flex items-center justify-center gap-2 rounded-xl border px-4 py-3 text-sm font-bold transition ${
            saved
              ? "border-[#10b981]/50 bg-[#10b981]/10 text-[#6ee7b7]"
              : "border-white/15 bg-white/5 text-white hover:border-[#7c5cff]/50 hover:bg-[#7c5cff]/10"
          } disabled:opacity-60`}
        >
          {saving ? (
            <>
              <div className="h-4 w-4 animate-spin rounded-full border-2 border-white/20 border-t-white" />
              جارٍ الحفظ...
            </>
          ) : saved ? (
            <>
              <svg className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2.5}>
                <path strokeLinecap="round" strokeLinejoin="round" d="M4.5 12.75l6 6 9-13.5" />
              </svg>
              تم الحفظ
            </>
          ) : (
            <>
              <svg className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                <path strokeLinecap="round" strokeLinejoin="round" d="M17.593 3.322c1.1.128 1.907 1.077 1.907 2.185V21L12 17.25 4.5 21V5.507c0-1.108.806-2.057 1.907-2.185a48.507 48.507 0 0111.186 0z" />
              </svg>
              حفظ في المعرض
            </>
          )}
        </button>
      </div>
    </div>
  );
}
