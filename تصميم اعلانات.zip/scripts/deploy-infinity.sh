#!/bin/bash
#
# 🌐 بناء موقع أَدفايز للنشر على InfinityFree
# الاستخدام: ./scripts/deploy-infinity.sh
#

set -e

echo "🌐 بناء موقع أَدفايز..."
echo ""

# تنظيف الملفات القديمة
rm -rf out/ .next/

# بناء الموقع (static export)
STATIC_EXPORT=true npm run build

if [ ! -d "out" ]; then
  echo "❌ فشل البناء"
  exit 1
fi

echo ""
echo "✅ تم! الموقع جاهز في مجلد out/"
echo ""
echo "📤 خطوات الرفع:"
echo "   1. افتح InfinityFree → File Manager → htdocs/"
echo "   2. احذف الملفات القديمة"
echo "   3. ارفع كل محتويات out/"
echo "   4. فعّل 'إظهار الملفات المخفية' لرفع .htaccess"
echo ""
echo "للتفاصيل: راجع INFINITYFREE_GUIDE.md"
