import type { NextConfig } from "next";

/**
 * إعدادات Next.js
 *
 * - الوضع الافتراضي: خادم (مع قاعدة بيانات) — للتطوير المحلي
 * - وضع الموقع: STATIC_EXPORT=true — ينتج ملفات HTML ثابتة للنشر على InfinityFree
 *
 * للنشر كموقع على InfinityFree:
 *   STATIC_EXPORT=true npm run build
 * ثم ارفع محتويات مجلد out/ إلى htdocs/
 */
const isStatic = process.env.STATIC_EXPORT === "true";

const nextConfig: NextConfig = {
  ...(isStatic
    ? {
        output: "export",
        images: { unoptimized: true },
      }
    : {}),
};

export default nextConfig;
